import React,{useState} from "react";
import axios from 'axios';
import { Form, Input, Button, Image, Row, Col } from "antd";
import "./index.css";
import { useHistory } from "react-router-dom";
import logo from "./logo.svg";
const layout = {
  labelCol: {
    span: 8,
  },
  wrapperCol: {
    span: 16,
  },
};
const tailLayout = {
  wrapperCol: {
    offset: 8,
    span: 16,
  },
};
const initUrl='http://127.0.0.1:3000/get/xtyCaptcha?='+Math.random();
function LoginDom(obj) {
  const login = () => {
    history.push("/product/a");
  };
  const [url,setUrl]=useState(initUrl)
  const updatePng = () =>{
    setUrl('http://127.0.0.1:3000/get/xtyCaptcha?='+Math.random())
  }
  const onFinish = (values) => {
    console.log("Success:", values);
    var requestdata = {
      "captcha": values.captcha,
      "data": {
              'eticketNo': values.eticketNo,
              'invoiceNo': values.invoiceNo,
              'price': values.price,
              'passengerName': values.passengerName,
          }
    }
    axios.post('http://127.0.0.1:3000/get/travel',JSON.stringify(requestdata),{withCredentials: true})
      .then(res => {
        var txetData = JSON.stringify(res.data);
        var textData = decodeURIComponent(txetData);
        console.log(textData); //先输出到控制台看一下
        alert(textData);
      })
      .catch(error => {
        console.log(error);
    });
    setUrl('http://127.0.0.1:3000/get/xtyCaptcha?='+Math.random())
  };

  const onFinishFailed = (errorInfo) => {
    console.log("Failed:", errorInfo);
  };
  const history = useHistory();

  return (
    <div className="App" src="./logo.svg">
      <header className="App-header">
        <img src={logo} className="App-logo" alt="logo" />

        <Form
          {...layout}
          name="basic"
          initialValues={{
            remember: true,
          }}
          onFinish={onFinish}
          onFinishFailed={onFinishFailed}
        >
          <Form.Item
            label="电子客票号"
            name="eticketNo"
            initialValue="731-2498491887"
            rules={[
              {
                required: true,
                message: "输入电子客票号码",
              },
            ]}
          >
            <Input />
          </Form.Item>

          <Form.Item
            label="印刷序号"
            name="invoiceNo"
            initialValue="13609319216"
            rules={[
              {
                required: true,
                message: "输入印刷序号",
              },
            ]}
          >
            <Input />
          </Form.Item>

          <Form.Item
            label="总价"
            name="price"
            initialValue="650"
            rules={[
              {
                required: true,
                message: "输入总价",
              },
            ]}
          >
            <Input />
          </Form.Item>

          <Form.Item
            label="乘客姓名"
            name="passengerName"
            initialValue="陈凤生"
            rules={[
              {
                required: true,
                message: "输入乘客姓名",
              },
            ]}
          >
            <Input />
          </Form.Item>

          <Form.Item label="验证码"  rules={[{required: true},]}>
            <Row gutter={8}>
              <Col span={12}>
                <Form.Item
                  name="captcha"
                  noStyle
                  rules={[{ required: true, message: '输入验证码' }]}
                >
                  <Input />
                </Form.Item>
              </Col>
              <Col span={12}>
                <img
                  width={100}
                  src={url}
                  onClick={updatePng}
                />
              </Col>
            </Row>
        </Form.Item>


          <Form.Item {...tailLayout}>
            <Button type="primary" htmlType="submit">
              Submit
            </Button>
          </Form.Item>
        </Form>
      </header>
    </div>
  );
}

export default LoginDom;
