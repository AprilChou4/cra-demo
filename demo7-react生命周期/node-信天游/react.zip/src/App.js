import {
  HashRouter as Router,
  Link,
  Route,
  Switch,
  useHistory,
  Redirect,
} from "react-router-dom";
import './App.css';
import LoginDom from "./xty";

const Login = () => {
  return <LoginDom />;
};

function App() {
  return (
    <div className="App">
      <Router>
        <div className="App">
          <Switch>
            {/* 重定向 如你启动时候地址是没有login的，就匹配不到路由，这个可以帮你重定向到login */}
            <Redirect exact path="/" to="/xty" />
            <Route path="/xty" exact component={Login} />
          </Switch>
        </div>
      </Router>
    </div>
  );
}

export default App;
