var crypto = require('crypto');

var document={};
var window = {
    navigator:
    {
        userAgent:"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/64.0.3282.140 Safari/537.36 Edge/18.17763"
    }
};

var xty_url = 'http://www.travelsky.com'
    
var chunk_vendors = require('./chunk-vendors');
chunk_vendors(window,document);

    t = window["webpackJsonp"][0][1]
    function e(e) {
        for (var s, r, o = e[0], c = e[1], l = e[2], v = 0, d = []; v < o.length; v++)
            r = o[v],
            Object.prototype.hasOwnProperty.call(a, r) && a[r] && d.push(a[r][0]),
            a[r] = 0;
        for (s in c)
            Object.prototype.hasOwnProperty.call(c, s) && (t[s] = c[s]);
        u && u(e);
        while (d.length)
            d.shift()();
        return n.push.apply(n, l || []),
        i()
    }
    function i() {
        for (var t, e = 0; e < n.length; e++) {
            for (var i = n[e], s = !0, o = 1; o < i.length; o++) {
                var c = i[o];
                0 !== a[c] && (s = !1)
            }
            s && (n.splice(e--, 1),
            t = r(r.s = i[0]))
        }
        return t
    }
    var s = {}
      , a = {
        app: 0
    }
      , n = [];
    function r(e) {
        if (s[e])
            return s[e].exports;
        var i = s[e] = {
            i: e,
            l: !1,
            exports: {}
        };
        if(t[e] != undefined)
        {
            return t[e].call(i.exports, i, i.exports, r),
            i.l = !0,
            i.exports
        }
    }
    r.m = t,
    r.c = s,
    r.d = function(t, e, i) {
        r.o(t, e) || Object.defineProperty(t, e, {
            enumerable: !0,
            get: i
        })
    }
    ,
    r.r = function(t) {
        "undefined" !== typeof Symbol && Symbol.toStringTag && Object.defineProperty(t, Symbol.toStringTag, {
            value: "Module"
        }),
        Object.defineProperty(t, "__esModule", {
            value: !0
        })
    }
    ,
    r.t = function(t, e) {
        if (1 & e && (t = r(t)),
        8 & e)
            return t;
        if (4 & e && "object" === typeof t && t && t.__esModule)
            return t;
        var i = Object.create(null);
        if (r.r(i),
        Object.defineProperty(i, "default", {
            enumerable: !0,
            value: t
        }),
        2 & e && "string" != typeof t)
            for (var s in t)
                r.d(i, s, function(e) {
                    return t[e]
                }
                .bind(null, s));
        return i
    }
    ,
    r.n = function(t) {
        var e = t && t.__esModule ? function() {
            return t["default"]
        }
        : function() {
            return t
        }
        ;
        return r.d(e, "a", e),
        e
    }
    ,
    r.o = function(t, e) {
        return Object.prototype.hasOwnProperty.call(t, e)
    }
    ,
    r.p = "/";
    var o = window["webpackJsonp"] = window["webpackJsonp"] || []
      , c = o.push.bind(o);
    o.push = e,
    o = o.slice();
    for (var l = 0; l < o.length; l++)
        e(o[l]);
    var u = c;
    n.push([0, "chunk-vendors"]),
    i()


    J = r("f8d5"), B = r.n(J),
    X = B.a.parse("GP09101ABEAUITGP"), Y = B.a.parse("0123456789ABCDEF"),
    Z = r("c198"), H = r.n(Z),
    U = r("6d08"), W = r.n(U);
    M = r("640f"), Q = r.n(M)
    L = r("1132"), K = r.n(L)
    G = r("94f8"), q = r.n(G)
    function z(t) {
        return t instanceof URLSearchParams ? t.toString() : t instanceof String || "string" == typeof t ? t : JSON.stringify(t)
    }
    //解密
    function xtyDecrypt(data)
    {
        var responseData = data
        var e = H.a.decrypt(responseData, X, {
                iv: Y,
                format: W.a
            })
              , i = e.toString(B.a)
              , s = JSON.parse(i);
              responseData = s
        return responseData
    }
    //加密
    function xtyEncrypt(data)
    {
        var requestData = data;
        var e = H.a.encrypt(JSON.stringify(requestData), X, {
            iv: Y
        });
        requestData = e.ciphertext.toString(Q.a)
        var i = q()(z(requestData))
            , s = requestData;
        requestData = {
            hash: i.toString(K.a),
            data: s
        }
        return requestData
    }
    
//加密服务
var http = require('http');
http.createServer(function (request, response) {
    // 发送 HTTP 头部 
    // HTTP 状态值: 200 : OK
    // 内容类型: text/plain
    var resData = {};
    var body = '';
    request.on('data',function(data){
        body += data;
        console.log('data' + data);
    });

    request.on('end',function(data){
        body = decodeURIComponent(body)
        var len = body.split('&').length;
            if(len > 0){
                for(var i=0;i<len;i++){
                    var key = body.split('&')[i];
                    resData[key.split('=')[0]] = key.split('=')[1];                         
                }
        }
        var ret = xtyEncrypt(resData);
        resData = {
            "statusCode": 200,
            "data": ret
    }
    response.writeHead(200,{'Content-Type':'application/x-json'});
    response.end(JSON.stringify(resData),'binary');  
    });
}).listen(8888);

//解密服务
var http_decrypt = require('http');
http_decrypt.createServer(function (request, response) {
    // 发送 HTTP 头部 
    // HTTP 状态值: 200 : OK
    // 内容类型: text/plain
    var resData = {};
    var body = '';
    request.on('data',function(data){
        body += data;
        console.log('data' + data);
    });

    request.on('end',function(data){
        body = decodeURIComponent(body)
        var len = body.split('&').length;
            if(len > 0){
                for(var i=0;i<len;i++){
                    var key = body.split('&')[i];
                    resData[key.split('=')[0]] = key.split('=')[1];                         
                }
        }
        var ret = xtyDecrypt(resData.data);
        resData = {
            "statusCode": 200,
            "data": ret
    }
    resData = JSON.stringify(resData)
    response.writeHead(200,{'Content-Type':'application/x-json; charset=utf-8'});
    response.end(encodeURIComponent(resData),'binary');  
    });
}).listen(8880);

/**************************************xty接口转发服务**********************************************/
//set-cookie处理
function handleSetCookie(setCookie){
    var len = setCookie.length;
    var cookie = {};
    for(var i=0;i<len;i++){
        var cookieItem = setCookie[i];
        if(cookieItem.indexOf(";")>-1){
            cookieItem = cookieItem.split(";");
            if(cookieItem[0].indexOf("=")>-1){
                cookieItem = cookieItem[0].split("=");
                cookie[cookieItem[0]]=cookieItem[1];
            }
        }
         
    }
    console.log(cookie);
    return cookie
}
//cookie处理
function handleCookie(cookie){
    var retCookie={};
    var inputCookie = cookie.split(";")
    var len = inputCookie.length;
    for(var i=0;i<len;i++){
        var cookieItem = inputCookie[i];
        if(cookieItem.indexOf("=")>-1){
            cookieItem = cookieItem.split("=");
            retCookie[cookieItem[0].replace(/(^\s*)|(\s*$)/g, "")]=cookieItem[1].replace(/(^\s*)|(\s*$)/g, "");
        }
    }
    return retCookie;
}
//获取json请求头
function getJsonHeaders(){
    var headers = {}
    headers['User-Agent'] = "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:75.0) Gecko/20100101 Firefox/75.0"
    headers['X-Requested-With'] = 'XMLHttpRequest'
    headers['Accept-Language'] = 'zh-CN,zh;q=0.9'
    headers['Accept'] = 'text/plain'
    headers['Content-Type'] = 'application/json;charset=UTF-8'
    headers['Connection'] = 'keep-alive'
    headers['Cache-Control'] = 'no-cache'
    headers['Pragma'] = 'no-cache'
    return headers;
}
//获取信天游验证码
function getXtyCaptcha(myResponse){
    var request = require('request');
    var fs = require("fs")
    var captchaUrl = xty_url+"/tsky/captcha";
    console.log("开始获取验证码");
    request({
                url: captchaUrl,
                method: "Get",
                headers: {
                    "Accept":"image/png, image/svg+xml, image/jxr, image/*; q=0.8, */*; q=0.5",
                    "User-Agent":"Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:75.0) Gecko/20100101 Firefox/75.0",
                    "content-type": "application/json",
                },
            },
            function (error, response, body){
                if(!error && response.statusCode == 200){
                    var stream = fs.createReadStream("captcha.png");
                    var responseData = [];//存储文件流
                    if (stream) {//判断状态
                        stream.on( 'data', function( chunk ) {
                        responseData.push( chunk );
                        });
                        stream.on( 'end', function() {
                        var finalData = Buffer.concat( responseData );
                        //信天游特殊处理
                        console.log('设置cookie')
                        var setCookie = response.headers['set-cookie']
                        var cookie = handleSetCookie(setCookie)
                        cookie['x-captcha-token-key']=response.headers['x-captcha-token-key']
                        myResponse.writeHead(200,[
                            ['Content-type','image/png'],
                            ['Set-Cookie','x-captcha-token-key='+cookie['x-captcha-token-key']],
                        ]);
                        myResponse.write(finalData);
                        myResponse.end();
                        });
                    }
                    return;
                }
                myResponse.writeHead(500);
                myResponse.end();  
    }).pipe(fs.createWriteStream("captcha.png"));
}
//获取信天游查询结果
function questTravel(data,myRequest,myResponse){
    myRequestData = JSON.parse(data)
    var ret = xtyEncrypt(myRequestData['data']);
    var travel_url = xty_url + "/tsky/tsky/validator";
    //获取解析请求cookie
    var cookie = myRequest.headers['cookie'];
    cookie = handleCookie(cookie);
    var requestHeaders = getJsonHeaders();
    requestHeaders['x-captcha-token-key'] = cookie['x-captcha-token-key']
    requestHeaders['x-captcha-token-value'] = myRequestData['captcha']
    requestHeaders['Origin'] = xty_url
    requestHeaders['Referer'] =xty_url + '/'
    console.log(requestHeaders)
    var request = require('request');
    console.log("开始获取验证码");
    request({
                url: travel_url,
                method: "Post",
                headers: requestHeaders,
                json :ret,
            },
            function (error, response, body){
                if(!error && response.statusCode == 200){
                        var ret = xtyDecrypt(body);
                        var resData = JSON.stringify(ret)
                        myResponse.writeHead(200,{'Content-Type':'application/x-json; charset=utf-8'});
                        myResponse.end(encodeURIComponent(resData),'binary');  
                        return;
                    }
                myResponse.writeHead(500);
                myResponse.end();  
    })
}
//端口8080-信天游服务
var http = require('http');
const { cookieCompare } = require('tough-cookie');
const { cookie } = require('request');
http.createServer(function (request, response) {
    // 发送 HTTP 头部 
    // HTTP 状态值: 200 : OK
    // 内容类型: text/plain
    var resData = {};
    var body = '';
    request.on('data',function(data){
        body += data;
        console.log('data' + data);
    });

    request.on('end',function(data){
        resData = decodeURIComponent(body);
        if(request.url.indexOf("/get/travel")>-1){
            questTravel(resData,request,response)
        } 
        if(request.url.indexOf("/get/xtyCaptcha?")>-1){
            getXtyCaptcha(response)
        }
    });
    
}).listen(8080);