# -*- coding: utf-8 -*-
from aUtilsGov import *


class ThirdPartyQuery(TaxGov):
    def __init__(self):
        super(ThirdPartyQuery, self).__init__()
        self.url = 'http://127.0.0.1:8888'

    def init_third_website(self):
        url = 'http://www.travelsky.com/'
        try:
            r = self.getRedirects(url)
            if r[0] is True:
                return r[1]['response']['data']
            return ''
        except Exception as e:
            return e

    def get_captcha_png(self):
        url = 'http://172.30.6.18:8080/get/xtyCaptcha'
        try:
            main_dir = os.getcwd()
            png_path = os.path.join(main_dir, "captcha.png")
            r = self.saveImgByGet(url=url, localFile=png_path)
            return ''
        except Exception as e:
            return e

    def quest_travel(self, quest_data, captcha_value):
        url = 'http://172.30.6.18:8080/quest/travel'
        try:
            r = self.postRequest(url=url, rqData=quest_data, qrHeaders=jsonHeaders())
            if r[0] is True:
                return r[1]
            return ''
        except Exception as e:
            return e


def main():

    query_obj = ThirdPartyQuery()
    query_obj.init_third_website()
    query_obj.get_captcha_png()

    captcha_value = input('输入验证码:')
    

    request_data = {
        "captcha": captcha_value,
        "data": {
                'eticketNo': "731-2498491887",
                'invoiceNo': "13609319216",
                'price': "650",
                'passengerName': "陈凤生"
            }
    }
    print(request_data)
    req = query_obj.quest_travel(request_data, captcha_value)
    print(req)

if __name__ == "__main__":
    main()
