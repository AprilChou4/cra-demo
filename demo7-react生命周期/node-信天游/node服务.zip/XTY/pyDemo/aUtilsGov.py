# -*- coding: utf8 -*-
import os
import importlib
import importlib.util
import copy
import collections

def checkModule(mName):
    mSpec = importlib.util.find_spec(mName)
    if mSpec is None:
        return None
    return mSpec


def dynamic_import(mModule):
    return importlib.import_module(mModule)


def outConsole(*value):
    if checkModule("externPy") is None:
        print(*value)
        return
    externC = dynamic_import("externPy")
    if externC is None:
        print(*value)
        return
    externC.OutConsole(*value)


# 移除ruler.txt文件
try:
    home = ""
    if "LOCALAPPDATA" in os.environ:
        home = os.environ["LOCALAPPDATA"]
        home += "\\GxptScripts"
    elif 'TEMP' in os.environ:
        home = os.path.dirname(os.environ["TEMP"])
        home += "\\Application Data\\GxptScripts"
    outConsole("debug", "home", home)
    if os.path.exists("ruler.txt"):
        os.remove("ruler.txt")
    rmTxt = home + "\\ruler.txt"
    outConsole("debug", "home", rmTxt)
    if os.path.exists(rmTxt):
        os.remove(rmTxt)
except Exception:
    pass

import requests
import random
import json
import urllib
import time
import datetime
import base64
import codecs
import requests.packages.urllib3.util.ssl_

TencentCtrl = 0
userAgentVal = "Mozilla/5.0 (Windows NT 10.0; WOW64; Trident/7.0; rv:11.0) like Gecko"
requests.packages.urllib3.util.ssl_.DEFAULT_CIPHERS = 'ALL'
requests.packages.urllib3.disable_warnings()


def mkUserAgent():
    agents = [
        "Mozilla/5.0 (Windows NT 10.0; WOW64; Trident/7.0; rv:11.0) like Gecko",
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/64.0.3282.140 Safari/537.36 Edge/18.17763",
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:75.0) Gecko/20100101 Firefox/75.0", "Mozilla/5.0 (Windows NT 6.1; WOW64; Trident/7.0; rv:11.0) like Gecko",
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/81.0.4044.113 Safari/537.36",
        "Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/81.0.4044.129 Safari/537.36"
    ]
    nA = random.randint(0, len(agents))
    if nA >= len(agents):
        nA = nA - 1
    return agents[nA]


userAgentVal = mkUserAgent()


def formHeaders():
    headers = {}
    headers['User-Agent'] = userAgentVal
    headers['X-Requested-With'] = 'XMLHttpRequest'
    headers['Accept-Language'] = 'zh-CN'
    headers['Accept'] = 'application/json, text/javascript, application/javascript, application/ecmascript, application/x-ecmascript, */*; q=0.01'
    headers['Content-Type'] = 'application/x-www-form-urlencoded;charset=utf-8;charset=UTF-8'
    headers['Connection'] = 'Keep-Alive'
    headers['Cache-Control'] = 'no-cache'
    headers['Pragma'] = 'no-cache'
    return headers


def jsonHeaders():
    headers = {}
    headers['User-Agent'] = userAgentVal
    headers['X-Requested-With'] = 'XMLHttpRequest'
    headers['Accept-Language'] = 'zh-CN,zh;q=0.9'
    headers['Accept'] = 'text/plain'
    headers['Content-Type'] = 'application/json;charset=UTF-8'
    headers['Connection'] = 'keep-alive'
    headers['Cache-Control'] = 'no-cache'
    headers['Pragma'] = 'no-cache'
    return headers


def htmlHeaders():
    headers = {}
    headers['User-Agent'] = userAgentVal
    headers['Upgrade-Insecure-Requests'] = '1'
    headers['Accept-Language'] = 'zh-CN'
    headers['Accept'] = 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8'
    headers['Content-Type'] = 'application/x-www-form-urlencoded;charset=utf-8'
    headers['Connection'] = 'Keep-Alive'
    return headers


def downHeaders():
    headers = {}
    headers['User-Agent'] = userAgentVal
    headers['Accept-Language'] = 'zh-Hans-CN,zh-Hans;q=0.5'
    headers['Accept'] = "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8"
    headers['Connection'] = 'Keep-Alive'
    headers['Cache-Control'] = 'no-cache'
    headers['Pragma'] = 'no-cache'
    headers["Accept-Encoding"] = "gzip, deflate, br"
    return headers


def copyCookies(input, output):
    for key, value in input.items():
        if isinstance(value, dict):
            for nm, val in value.items():
                if isinstance(val, str):
                    output[nm] = val
                elif hasattr(value, "value"):
                    output[key] = value.value
                else:
                    copyCookies(val, output)
        elif isinstance(value, str):
            output[key] = value
        elif hasattr(value, "value"):
            output[key] = value.value
    return input


def getCoding(strInput):
    # 获取编码格式
    if isinstance(strInput, str):
        return 'unicode'
    try:
        codecs.decode(strInput, "utf8")
        return 'utf8'
    except Exception:
        pass
    try:
        codecs.decode(strInput, "gbk")
        return 'gbk'
    except Exception:
        pass


def tran2UTF8(strInput):
    # 转化为utf8格式
    strCodingFmt = getCoding(strInput)
    if strCodingFmt == "utf8":
        return strInput
    elif strCodingFmt == "unicode":
        # byte转字符串
        return bytes.decode(codecs.encode(strInput, 'utf8'))
    elif strCodingFmt == "gbk":
        # byte转字符串
        return bytes.decode(codecs.encode(codecs.decode(strInput, "gbk"), "utf8"))
    return strInput


def tran2GBK(strInput):
    # 转化为gbk格式
    byteStr = strInput
    try:
        if isinstance(strInput, str):
            byteStr = strInput.encode('ISO8859-1')
        return byteStr.decode('gbk')
    except Exception:
        return strInput


def getTimeMillis():
    return str(round(time.time() * 1000))


def getCurPath():
    return os.path.split(os.path.realpath(__file__))[0]


def handleResponse(response):
    if response.status_code != 200:
        return False, 'code ' + str(response.status_code)
    datatype = text = ''
    if 'Content-Type' in response.headers:
        datatype = response.headers['Content-Type']
        datatype = datatype.lower()
    if datatype.find('image') != -1 or datatype.find('file') != -1:
        content = b''
        for chunk in response.iter_content(1000000):
            content += chunk
        return True, content, datatype
    else:
        for chunk in response.iter_content(1000000):
            try:
                text += chunk.decode()
            except Exception:
                text += tran2UTF8(chunk)
    if len(text) == 0:
        text = response.text
    if datatype.find('html') != -1:
        return True, text, datatype
    if datatype.find("javascript") != -1:
        return True, text, datatype
    startL = text.find('{')
    startR = text.rfind('}')
    if startL != -1 and startR != -1:
        result = text[startL:startR + 1].strip()
        return True, json.loads(result), "json"
    startL = text.find('[')
    startR = text.rfind(']')
    if startL != -1 and startR != -1:
        result = text[startL:startR + 1].strip()
        return True, json.loads(result), "json"
    return True, text, "text/html"


def postNuonuoMM(key, val, area=""):
    url = 'https://cszs.jss.com.cn/jsencrypt/LNshRSA.do'
    if area is not None and area == 'SHANGHAI':
        url = 'https://cszs.jss.com.cn/jsencrypt/shRSA.do'
    rqData = {}
    headers = {
        "User-Agent": "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/77.0.3865.120 Safari/537.36",
    }
    try:
        s = requests.Session()
        s.trust_env = False
        s.keep_alive = False
        rqData['key'] = key
        rqData['val'] = val
        r = s.post(url, verify=False, headers=headers, data=rqData, timeout=20)
        if r.status_code != 200:
            return False, str(r.status_code)
        text = json.loads(r.text)
        r.close()
        if str(text['statusCode']) != '200':
            if 'message' in text and text['message'] is not None:
                return False, text['message']
            return False, ''
        return True, text['body']
    except requests.exceptions.Timeout:
        return False, '请求云计算密钥串超时'
    except requests.exceptions.RequestException:
        return False, '请求云计算密钥串超时'
    except Exception:
        return False, '请求云计算密钥串超时'


def postServerlessApi(key, val, area=""):
    url = 'https://service-jfx3tfxj-1252292487.sh.apigw.tencentcs.com/release/LNshRSA'
    if area is not None and area == 'SHANGHAI':
        url = 'https://service-5ur6aimn-1252292487.sh.apigw.tencentcs.com/release/shRSA'
    rqData = {}
    headers = {
        "User-Agent": "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/77.0.3865.120 Safari/537.36",
    }
    try:
        s = requests.Session()
        s.trust_env = False
        s.keep_alive = False
        rqData['key'] = key
        rqData['val'] = val
        r = s.post(url, verify=False, headers=headers, data=rqData, timeout=20)
        if r.status_code != 200:
            return False, str(r.status_code)
        text = json.loads(r.text)
        r.close()
        if text['statusCode'] != 200:
            return False, text['body']
        return True, text['body']
    except requests.exceptions.Timeout:
        return False, '请求云计算密钥串超时'
    except requests.exceptions.RequestException:
        return False, '请求云计算密钥串超时'
    except Exception:
        return False, '请求云计算密钥串超时'


def postTencentMM(key, val, area=""):
    global TencentCtrl
    if TencentCtrl == 0:
        cryptVal = postNuonuoMM(key, val, area)
        if cryptVal[0] is True:
            TencentCtrl += 1
            return cryptVal
        cryptVal = postServerlessApi(key, val, area)
        return cryptVal
    else:
        TencentCtrl = 0
        cryptVal = postServerlessApi(key, val, area)
        return cryptVal


def isJsonStr(v):
    try:
        obj = json.loads(v)
        return True, obj
    except Exception:
        return False, v


def KprqQ():
    dtNow = datetime.datetime.now()
    return dtNow.strftime("%Y-%m-01")


def KprqZ():
    dtNow = datetime.datetime.now()
    return dtNow.strftime("%Y-%m-%d")


def urlEncode(val):
    return urllib.parse.quote(str(val), safe="-_.!~*'()")


def int2str(val):
    if isinstance(val, int):
        return str(val)
    if val is None:
        return "0"
    if isinstance(val, str):
        return val
    return str(val)


def buildCallback():
    retVar = '?callback=jQuery'
    retVar += str(random.randint(1000000000000000000000, 9999999999999999999999))
    retVar += '_'
    retVar += str(random.randint(1000000000000, 9999999999999))
    return retVar


# debug,info,error
def uplog(nsrsh, act, param, msg, module="", lv='info'):
    if nsrsh is None or nsrsh == '':
        return
    data = {'clientVersion': "etax", 'clientName': 'etax', 'appId': 'nuonuo-cszs-cli'}
    data["app_module"] = "etax" if module == "" or module is None else module
    data["action"] = str(act)
    data["logLevel"] = lv
    data["taxId"] = nsrsh
    data["message"] = str(msg) + '\n' + str(param)
    headers = {"content-type": "application/json"}
    try:
        if checkModule("Crypto") is None:
            return
        mAES = dynamic_import("Crypto.Cipher.AES")
        mPAD = dynamic_import("Crypto.Util.Padding")
        if mAES is None or mPAD is None:
            return
        jsonData = json.dumps(data, ensure_ascii=False)
        pad_pkcs7 = mPAD.pad(jsonData.encode(), mAES.block_size, style='pkcs7')  # 选择pkcs7补全
        cipher = mAES.new('R1cAUtcAVzBwDHgN'.encode(), mAES.MODE_ECB)
        encrypted = cipher.encrypt(pad_pkcs7)  # aes加密
        upData = base64.encodebytes(encrypted).decode('utf8').replace('\n', '')  # base64 encode
        s = requests.Session()
        r = s.post('http://jslog.jss.com.cn/helper/v2/logs', verify=False, headers=headers, data=upData, timeout=10)
        # 关闭请求  释放内存
        r.close()
    except Exception as s:
        outConsole(str(s))

def HaveVirtualUkey(nsrsh):
    rqHeader = collections.OrderedDict()
    rqHeader['Accept'] = "*/*"
    rqHeader['Accept-Encoding'] = "gzip, deflate, br"
    rqHeader['Accept-Language'] = "zh-CN,zh;q=0.9"
    rqHeader['Cache-Control'] = "max-age=0"
    rqHeader['Connection'] = "keep-alive"
    rqHeader['Content-Length'] = "0"
    rqHeader['Content-Type'] = "application/x-www-form-urlencoded"
    rqHeader['Upgrade-Insecure-Requests'] = "1"
    rqHeader['User-Agent'] = "Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/84.0.4147.105 Safari/537.36"
    try:
        s = requests.Session()
        r = s.post("https://127.0.0.1:29000/api/readCertList", verify=False, params={}, headers=rqHeader, timeout=15)
        rpJson = isJsonStr(r.text)
        r.close()
        del (r)
        if rpJson[0] is False:
            return False, '请检查网络'
        if rpJson[1]['code'] != '0':
            return False, rpJson[1]['msg']
        for item in rpJson[1]['list']:
            if item['nsrsbh'] == nsrsh and nsrsh is not None and nsrsh != '':
                return True, item
        return False, '无此税号设备'
    except Exception as s:
        outConsole(str(s))
        return False, "服务访问超时"


def buildFormParam(rqData):
    rpStr = ''
    if isinstance(rqData, str):
        rpStr = rqData
    else:
        for (k, v) in rqData.items():
            if k == 'token':
                rpStr += k + '=' + str(v) + '&'
            else:
                rpStr += k + '=' + urlEncode(v) + '&'
    rpStr = rpStr.strip('&')
    return rpStr


def VirtualUKeyHello(nsrsh):
    upData = collections.OrderedDict()
    upData['nsrsbh'] = nsrsh
    upData['authtype'] = '0'
    rqStr = buildFormParam(upData)
    rqHeader = collections.OrderedDict()
    rqHeader['Accept'] = "*/*"
    rqHeader['Accept-Encoding'] = "gzip, deflate, br"
    rqHeader['Accept-Language'] = "zh-CN,zh;q=0.9"
    rqHeader['Cache-Control'] = "max-age=0"
    rqHeader['Connection'] = "keep-alive"
    rqHeader['Content-Length'] = str(len(rqStr))
    rqHeader['Content-Type'] = "application/x-www-form-urlencoded"
    rqHeader['Upgrade-Insecure-Requests'] = "1"
    rqHeader['User-Agent'] = "Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/84.0.4147.105 Safari/537.36"
    try:
        s = requests.Session()
        r = s.post('https://127.0.0.1:29000/api/clientHello', verify=False, headers=rqHeader, data=rqStr, timeout=15)
        rpJson = isJsonStr(r.text)
        r.close()
        del (r)
        if rpJson[0] is False:
            return False, "请检查网络"
        if rpJson[1]['code'] != '0':
            return False, rpJson[1]['msg']
        return True, rpJson[1]['clientHello']
    except Exception as s:
        outConsole(str(s))
        return False, "服务访问超时"


def VirtualUKeyAuth(nsrsh, auth):
    upData = collections.OrderedDict()
    upData['nsrsbh'] = nsrsh
    upData['serverHello'] = auth
    rqStr = buildFormParam(upData)
    rqHeader = collections.OrderedDict()
    rqHeader['Accept'] = "*/*"
    rqHeader['Accept-Encoding'] = "gzip, deflate, br"
    rqHeader['Accept-Language'] = "zh-CN,zh;q=0.9"
    rqHeader['Cache-Control'] = "max-age=0"
    rqHeader['Connection'] = "keep-alive"
    rqHeader['Content-Length'] = str(len(rqStr))
    rqHeader['Content-Type'] = "application/x-www-form-urlencoded"
    rqHeader['Upgrade-Insecure-Requests'] = "1"
    rqHeader['User-Agent'] = "Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/84.0.4147.105 Safari/537.36"
    try:
        s = requests.Session()
        r = s.post('https://127.0.0.1:29000/api/clientAuth', verify=False, headers=rqHeader, data=rqStr, timeout=15)
        rpJson = isJsonStr(r.text)
        r.close()
        del (r)
        if rpJson[0] is False:
            return False, "请检查网络"
        if rpJson[1]['code'] != '0':
            return False, rpJson[1]['msg']
        return True, rpJson[1]['clientAuth']
    except Exception as s:
        outConsole(str(s))
        return False, "服务访问超时"


class TaxGov:

    def __init__(self):
        self._cookie = {}
        self._host = ''
        self.rqSession = requests.Session()
        self.rqSession.trust_env = False
        self.rqSession.keep_alive = True

    def setHost(self, host):
        self._host = host

    def saveImgByGetXty(self, url, localFile, qrHeaders=formHeaders()):
        qrHeaders['Accept'] = "image/png, image/svg+xml, image/jxr, image/*; q=0.8, */*; q=0.5"
        try:
            r = self.rqSession.get(url, verify=False, cookies=self._cookie, headers=qrHeaders, timeout=40)
            copyCookies(r.cookies._cookies, self._cookie)
            outConsole("start", url)
            if r.status_code != 200:
                return False, 'code ' + str(r.status_code)
            if localFile != 'memory':
                playFile = open(localFile, 'wb')
                for chunk in r.iter_content(1000000):
                    playFile.write(chunk)
                playFile.close()
            content = b''
            for chunk in r.iter_content(1000000):
                content += chunk
            key = r.headers.get('X-Captcha-Token-Key')
            self._cookie['x-captcha-token-key']=key
            return True, content, key
        except IOError as e:
            return False, '文件处理异常 ' + str(e)
        except requests.exceptions.Timeout:
            return False, "请求局端服务超时"
        except requests.exceptions.RequestException:
            return False, "请求局端服务异常"
        except Exception as s:
            return False, str(s)

    def saveImgByGet(self, url, localFile, qrHeaders=formHeaders()):
        qrHeaders['Accept'] = "image/png, image/svg+xml, image/jxr, image/*; q=0.8, */*; q=0.5"
        try:
            r = self.rqSession.get(url, verify=False, cookies=self._cookie, headers=qrHeaders, timeout=40)
            copyCookies(r.cookies._cookies, self._cookie)

            self._cookie['ads_id']='ads_id'
            outConsole("start", url)
            if r.status_code != 200:
                return False, 'code ' + str(r.status_code)
            if localFile != 'memory':
                playFile = open(localFile, 'wb')
                for chunk in r.iter_content(1000000):
                    playFile.write(chunk)
                playFile.close()
            content = b''
            for chunk in r.iter_content(1000000):
                content += chunk
            return True, content
        except IOError as e:
            return False, '文件处理异常 ' + str(e)
        except requests.exceptions.Timeout:
            return False, "请求局端服务超时"
        except requests.exceptions.RequestException:
            return False, "请求局端服务异常"
        except Exception as s:
            return False, str(s)

    def  getRedirects(self, url, redata=None ,qrHeaders=formHeaders(), callback=None):
        try:
            uri = urllib.parse.urlsplit(url)
            self.allow_redirects = False
            r = self.rqSession.get(url, verify=False, allow_redirects=False, headers=qrHeaders, cookies=self._cookie, timeout=30)
            copyCookies(r.cookies._cookies, self._cookie)
            if r.status_code == 301 or r.status_code == 302:
                location = r.headers.get('Location')
                if 'http' not in url:
                    location = uri[0] + '://' + uri[1] + location  # 拼接host域名
                if callback is not None:
                    callback(location, qrHeaders)
                return self.getRedirects(location, qrHeaders, callback)
            if r.status_code != 200:
                return False, 'code ' + str(r.status_code)
            text = ''
            for chunk in r.iter_content(1000000):
                text += chunk.decode()
            if len(text) == 0:
                text = r.text
            reDirUrl = r.url
            r.close()
            del (r)
            return True, text, reDirUrl
        except requests.exceptions.Timeout:
            return False, "请求局端服务超时"
        except requests.exceptions.RequestException:
            return False, "请求局端服务异常"
        except Exception as s:
            outConsole("warring", str(s))
            return False, str(s)

    def getHtml(self, url, allowRefer=True, qrHeaders=htmlHeaders()):
        try:
            uri = urllib.parse.urlsplit(url)
            if allowRefer is True:
                qrHeaders['Referer'] = self._host + '/'
            rqh = copy.copy(qrHeaders)
            if 'Content-Type' in rqh:
                del rqh['Content-Type']
            self.allow_redirects = allowRefer
            r = self.rqSession.get(url, verify=False, allow_redirects=True, headers=rqh, cookies=self._cookie, timeout=30)
            copyCookies(r.cookies._cookies, self._cookie)
            outConsole("warring", url)
            if r.status_code != 200:
                return False, 'code ' + str(r.status_code)
            text = ''
            for chunk in r.iter_content(1000000):
                text += chunk.decode()
            if len(text) == 0:
                text = r.text
            r.close()
            del (r)
            return True, text
        except requests.exceptions.Timeout:
            return False, "请求局端服务超时"
        except requests.exceptions.RequestException:
            return False, "请求局端服务异常"
        except Exception as s:
            outConsole("warring", str(s))
            return False, str(s)
    
    def getRequest_(self, url, rqData, qrHeaders=formHeaders()):
        try:
            uri = urllib.parse.urlsplit(url)
            self.allow_redirects = False
            r = self.rqSession.get(url, verify=False,data=rqData, allow_redirects=False, headers=qrHeaders, cookies=self._cookie, timeout=30)
            outConsole("warring", url)
            copyCookies(r.cookies._cookies, self._cookie)
            rqResult = handleResponse(r)
            if rqResult[0] is False:
                print(rqResult[1])
                return rqResult
            r.close()
            del (r)
            return rqResult
        except requests.exceptions.Timeout:
            return False, "请求局端服务超时"
        except requests.exceptions.RequestException:
            return False, "请求局端服务异常"
        except Exception as s:
            outConsole("warring", str(s))
            return False, str(s)

    def getRequest(self, url, data, qrHeaders=formHeaders()):
        try:
            uri = urllib.parse.urlsplit(url)
            qrHeaders['Host'] = uri[1]
            if 'Referer' not in qrHeaders:
                qrHeaders['Referer'] = self._host + '/'
            if data is None or data == '':
                rqhs = copy.copy(qrHeaders)
                if 'Content-Type' in rqhs:
                    del rqhs['Content-Type']
                r = self.rqSession.get(url, verify=False, headers=rqhs, cookies=self._cookie, timeout=30)
            else:
                r = self.rqSession.get(url, verify=False, params=data, headers=qrHeaders, cookies=self._cookie, timeout=30)
            outConsole("warring", url)
            copyCookies(r.cookies._cookies, self._cookie)
            rqResult = handleResponse(r)
            if rqResult[0] is False:
                print(rqResult[1])
                return rqResult
            r.close()
            del (r)
            return rqResult
        except requests.exceptions.Timeout:
            return False, "请求局端服务超时"
        except requests.exceptions.RequestException:
            return False, "请求局端服务异常"
        except Exception as s:
            outConsole("warring", str(s))
            return False, str(s)
    
    def postRequest_(self, url, rqData, qrHeaders=formHeaders()):
        try:
            uri = urllib.parse.urlsplit(url)
            self.allow_redirects = False
            if qrHeaders['Content-Type'].find('json') != -1:
                r = self.rqSession.post(url, verify=False, headers=qrHeaders, cookies=self._cookie, json=rqData, timeout=30)
            else:
                r = self.rqSession.post(url, verify=False,data=rqData, allow_redirects=False, headers=qrHeaders, cookies=self._cookie, timeout=30)
            outConsole("warring", url)
            copyCookies(r.cookies._cookies, self._cookie)
            rqResult = handleResponse(r)
            if rqResult[0] is False:
                print(rqResult[1])
                return rqResult
            r.close()
            del (r)
            return rqResult
        except requests.exceptions.Timeout:
            return False, "请求局端服务超时"
        except requests.exceptions.RequestException:
            return False, "请求局端服务异常"
        except Exception as s:
            outConsole("warring", str(s))
            return False, str(s)
    
    def postRequest(self, url, rqData, qrHeaders=formHeaders()):
        try:
            uri = urllib.parse.urlsplit(url)
            qrHeaders['Host'] = uri[1]
            if 'Referer' not in qrHeaders:
                qrHeaders['Referer'] = self._host + '/'
            if qrHeaders['Content-Type'].find('json') != -1:
                r = self.rqSession.post(url, verify=False, headers=qrHeaders, cookies=self._cookie, json=rqData, timeout=30)
            else:
                r = self.rqSession.post(url, verify=False, headers=qrHeaders, cookies=self._cookie, data=rqData, timeout=30)
            outConsole("warring", url)
            copyCookies(r.cookies._cookies, self._cookie)
            rqResult = handleResponse(r)
            if rqResult[0] is False:
                print(rqResult[1])
                return rqResult
            r.close()
            del (r)
            return rqResult
        except requests.exceptions.Timeout:
            return False, "请求局端服务超时"
        except requests.exceptions.RequestException:
            return False, "请求局端服务异常"
        except Exception as s:
            outConsole("warring", str(s))
            return False, str(s)

    def getDownload(self, url, savefile, form, qrHeaders=downHeaders()):
        try:
            s = requests.Session()
            s.keep_alive = True
            remoteRes = s.get(url, verify=False, data=form, headers=qrHeaders, cookies=self._cookie, timeout=60)
            if remoteRes.status_code != 200:
                return False, '服务异常'
            copyCookies(remoteRes.cookies._cookies, self._cookie)
            if remoteRes.headers['Content-Type'].find('text/html') != -1:
                return False, remoteRes.text
            elif 'content-disposition' not in remoteRes.headers:
                return False, '下载数据异常'
            playFile = open(savefile, 'wb')
            for chunk in remoteRes.iter_content(1000000):
                playFile.write(chunk)
            playFile.close()
            rpParts = remoteRes.headers['content-disposition'].split(';')
            saveAsTar = savefile  # 文件另存为
            for partName in rpParts:
                if partName.find('filename') != -1:  # 移除多余字符
                    filenamevals = partName.split('=')
                    filenamevals[1] = filenamevals[1].replace('"', '')
                    filenamevals[1] = filenamevals[1].replace("'", '')
                    filenamevals[1] = filenamevals[1].replace(";", '')
                    realName = tran2GBK(filenamevals[1])
                    filefullname = saveAsTar[0:saveAsTar.rfind('.')]
                    filefullname += '.' + filenamevals[1].split('.')[1]
                    saveAsTar = filefullname
                    break
            if savefile != saveAsTar:
                if os.path.exists(saveAsTar):
                    os.remove(saveAsTar)
                os.rename(savefile, saveAsTar)
            # 关闭请求  释放内存
            remoteRes.close()
            del (remoteRes)
            return True, {'saveas': saveAsTar, 'filename': realName}
        except IOError:
            return False, "文件处理异常"
        except requests.exceptions.Timeout:
            return False, "请求服务超时"
        except requests.exceptions.RequestException:
            return False, "请求服务异常"
        except Exception as s:
            return False, str(s)
