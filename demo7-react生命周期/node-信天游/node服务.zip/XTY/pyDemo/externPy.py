import mmap
import sys
import subprocess
import json
import os

JsCtx = None

def OutConsole(*value):
    fmtOut = '\033[1;36m {0} \033[0m'
    for s in value:
        if s == 'debug':
            fmtOut = '\033[1;32m {0} \033[0m'
        elif s == 'error':
            fmtOut = '\033[1;31m {0} \033[0m'
        elif s == 'warning':
            fmtOut = '\033[1;33m {0}\033[0m'
        elif s == 'trace':
            fmtOut = '\033[1;36m {0}\033[0m'
        else:
            print(fmtOut.format(s))
    return


def IsLocalCA():
    return True


def CheckEnv():
    retDict = {'result': False}
    try:
        pyMm = mmap.mmap(-1, 20480, access=mmap.ACCESS_WRITE, tagname='share_mmap')
        if pyMm == None:
            retDict['data'] = '创建共享内存失败'
            return retDict
        DevCaExe = sys.path[0] + '\\DevCa.exe' + ' check memory=share_mmap'
        spc = subprocess.Popen(DevCaExe, stdin=None, stdout=None, shell=True)
        spc.wait()
        s = pyMm.read(20480).decode('UTF-16')
        if len(s) <= 0:
            retDict['data'] = '数据异常'
            return retDict
        s = s[0:s.rfind('}') + 1]
        jsn = json.loads(s)
        retDict['result'] = True
        retDict['nsrsh'] = jsn['nsrsh']
        retDict['nsrmc'] = jsn['nsrmc']
    finally:
        pyMm.close()
    return retDict


def ValidDev(pwd):
    retDict = {'result': False}
    try:
        pyMm = mmap.mmap(-1, 20480, access=mmap.ACCESS_WRITE, tagname='share_mmap')
        if pyMm == None:
            retDict['data'] = '创建共享内存失败'
            return retDict
        DevCaExe = sys.path[0] + '\\DevCa.exe' + ' valid pwd=' + pwd + ' memory=share_mmap'
        spc = subprocess.Popen(DevCaExe, stdin=None, stdout=None, shell=True)
        spc.wait()
        s = pyMm.read(20480).decode('UTF-16')
        if len(s) <= 0:
            retDict['data'] = '数据异常'
            return retDict
        s = s[0:s.rfind('}') + 1]
        jsn = json.loads(s)
        retDict['result'] = True
        retDict['nsrsh'] = jsn['nsrsh']
        retDict['nsrmc'] = jsn['nsrmc']
    finally:
        pyMm.close()
    return retDict


def MakeClientHello(pwd):
    retDict = {'result': False}
    try:
        pyMm = mmap.mmap(-1, 20480, access=mmap.ACCESS_WRITE, tagname='share_mmap')
        if pyMm == None:
            retDict['data'] = '创建共享内存失败'
            return retDict
        DevCaExe = sys.path[0] + '\\DevCa.exe' + ' hello pwd=' + pwd + ' memory=share_mmap'
        spc = subprocess.Popen(DevCaExe, stdin=None, stdout=None, shell=True)
        spc.wait()
        s = pyMm.read(20480).decode('UTF-16')
        if len(s) <= 0:
            retDict['data'] = '数据异常'
            return retDict
        s = s[0:s.rfind('}') + 1]
        jsn = json.loads(s)
        retDict['result'] = jsn['suc']
        if jsn['suc']:
            retDict['nsrsh'] = jsn['nsrsh']
            retDict['nsrmc'] = jsn['nsrmc']
            retDict['data'] = jsn['hello']
        else:
            retDict['data'] = jsn['msg']
    finally:
        pyMm.close()
    return retDict


def MakeSign(pwd, data):
    retDict = {'result': False}
    try:
        pyMm = mmap.mmap(-1, 12048000, access=mmap.ACCESS_WRITE, tagname='share_mmap')
        if pyMm == None:
            retDict['data'] = '创建共享内存失败'
            return retDict
        pyMm.seek(0)
        pyMm.write(bytes(data, 'ascii'))
        DevCaExe = sys.path[0] + '\\DevCa.exe' + ' sign pwd=' + pwd + ' memory=share_mmap' + ' id=SHA1withRSA'
        spc = subprocess.Popen(DevCaExe, stdin=None, stdout=None, shell=True)
        spc.wait()
        pyMm.seek(0)
        s = pyMm.read(12048000).decode('UTF-16')
        if len(s) <= 0:
            retDict['data'] = '数据异常'
            return retDict
        s = s[0:s.rfind('}') + 1]
        jsn = json.loads(s)
        retDict['result'] = True
        retDict['data'] = jsn['sign']
    except Exception as s:
        OutConsole(str(s))
    finally:
        pyMm.close()
    return retDict


def MakeClientAuthCode(pwd, hello):
    retDict = {'result': False}
    try:
        pyMm = mmap.mmap(-1, 120480, access=mmap.ACCESS_WRITE, tagname='share_mmap')
        if pyMm == None:
            retDict['data'] = '创建共享内存失败'
            return retDict
        pyMm.seek(0)
        pyMm.write(bytes(hello, 'ascii'))
        DevCaExe = sys.path[0] + '\\DevCa.exe' + ' auth pwd=' + pwd + ' memory=share_mmap'
        spc = subprocess.Popen(DevCaExe, stdin=None, stdout=None, shell=True)
        spc.wait()
        pyMm.seek(0)
        s = pyMm.read(120480).decode('UTF-16')
        if len(s) <= 0:
            retDict['data'] = '数据异常'
            return retDict
        s = s[0:s.rfind('}') + 1]
        jsn = json.loads(s)
        retDict['result'] = True
        retDict['data'] = jsn['auth']
    except Exception as s:
        OutConsole(str(s))
    finally:
        pyMm.close()
    return retDict


def execJS(m, *v):
    global JsCtx
    if JsCtx is None:
        jsf = open(sys.path[0] + '\\gxpt.js', 'r')
        jsCode = jsf.read()
        #.compile(jsCode)
    retDict = {'result': False, 'data': '缺少js运行环境'}
    if m == 'checkTaxno':
        data = JsCtx.call('jQueryT.checkTaxno', v[0], v[1], v[2], v[3], v[4])
        retDict['data'] = data
        return retDict
    if m == 'ck':
        data = JsCtx.call('jQueryT.checkBase', v[0], v[1], v[2], v[3], v[4])
        retDict['data'] = data
        return retDict
    if m == 'checkOneInv':
        data = JsCtx.call('jQueryT.checkOneInv', v[0], v[1], v[2], v[3], v[4], v[5], v[6])
        retDict['data'] = data
        return retDict
    if m == 'checkInvConf':
        data = JsCtx.call('jQueryT.checkBase', v[0], v[1], v[2], v[3], v[4])
        retDict['data'] = data
        return retDict
    return retDict


if __name__ == "__main__":
    #nowdate = str(datetime.date.today())
    ss = os.path.dirname('C:/test/someone/llll/cccc.ini')
    #inData = '<tr><td>未勾选</td><td><font>4</td><td>32,300.63</td><td>4,145.47</td><td><a onclick=gxAll(); href="javascript:void(0);" id="gx"><font color=red><u>全部勾选</u></a>&nbsp;&nbsp;&nbsp;&nbsp'
    #outTr = re.findall('<tr>(.*?)</a>',inData,re.I|re.M)
    #for val in outTr:
    #    out = re.findall('<td>(.*?)</td>',val,re.I|re.M)
    #    for index,value in enumerate(out):
    #        out[index] = value.replace('<font>','')
    #OutConsole('debug','test')
    #CheckEnv()
    #ValidDev('88888888')
    #print(str(MakeClientHello('88888888')))
    #execJS('ck', '91330381769616904K', '1566366274367', "",
    #       '$.bs.encode($.bs.encode($.bs.encode($.gen(a,c2))+$.gen(b,c2)+"")+$.gen($.xx($.encrypt($.gen(a,c2))),$.xx($.encrypt($.xx(b))))).toUpperCase()',
    #       '4155544853455256455248454c4c4f3203002400060000000000000000002400a1f4ceda956fad1b562a5cb600f92ea68ad95c5da1f4ceda956fad1b562a5cb600f92ea6')
