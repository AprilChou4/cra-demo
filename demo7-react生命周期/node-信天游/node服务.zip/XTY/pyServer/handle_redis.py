# encoding=utf-8
import redis


class XtyRedis:
    def __init__(self, host, port):
        self.redis_obj = redis.Redis(host=host, port=port, decode_responses=True)

    def set(self, name, value, ex=60):
        return self.redis_obj.set(name, value, ex)

    def get(self, name):
        return self.redis_obj.get(name)

    def delete(self, name):
        return self.redis_obj.delete(name)


if __name__ == '__main__':
    redis_obj = redis.Redis(host='localhost', port=6379, decode_responses=True)
    redis_obj.set('test',{'a','b'})
    r = redis_obj.hmget('test')
    print(r)
