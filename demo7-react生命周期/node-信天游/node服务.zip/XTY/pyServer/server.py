# encoding=utf-8
import os
import time
import uvicorn
import json
from typing import Optional
from pydantic import BaseModel
from handle_redis import XtyRedis
from xtyDemo import ThirdPartyQuery
from fastapi import FastAPI, Response, Cookie
from starlette.responses import FileResponse

class XtyRequestData(BaseModel):
    eticketNo: str  # 电子客票号
    invoiceNo: str  # 印刷序列号
    price: str  # 票价
    passengerName: str  # 行程人名字


class TravelData(BaseModel):
    captcha: str
    data: XtyRequestData


class XtyApp(FastAPI):
    get_captcha_result = {
        "400": {"code": 400, "msg": "服务异常", "data": None},
        "500": {"code": 500, "msg": "创建进项文件夹失败", "data": None},
        "501": {"code": 500, "msg": "获取验证码超时", "data": None},
        "502": {"code": 500, "msg": "验证码已过期", "data": None},
        "503": {"code": 500, "msg": "数据加密失败", "data": None},
        "504": {"code": 500, "msg": "数据解密失败", "data": None},
    }

    def __init__(self):
        FastAPI.__init__(self)
        self.redis_port = 6379
        self.redis_host = 'localhost'
        self.redis_obj = XtyRedis(self.redis_host, self.redis_port)
        self.node_url = 'http://127.0.0.1'
        self.xty_url = 'http://www.travelsky.com'

    def get_captcha_png(self):
        try:
            cookie = dict()
            third_obj = ThirdPartyQuery(self.xty_url, cookie)
            # 初始化信天游对象
            init_times = 5
            while init_times > 0:
                init_times = init_times - 1
                r = third_obj.init_third_website()
                if r is True:
                    break
                time.sleep(1)
            else:
                return '500', ''
            # 获取验证码
            get_captcha_times = 5;
            while get_captcha_times > 0:
                get_captcha_times = get_captcha_times - 1
                r = third_obj.get_captcha_png()
                if r[0] is True:
                    # 信天游验证码token：cookie存入redis
                    self.redis_obj.set(r[2], json.dumps(third_obj._cookie))
                    return '200', r[1], r[2]
                time.sleep(1)
            else:
                return '501', ''

            return '400', ''
        except BaseException as e:
            return '400', ''

    def quest_travel(self, token, request_data, captcha):
        try:
            cookie = self.redis_obj.get(token)
            if cookie is None:
                return '502', ''
            cookie = json.loads(cookie)
            third_obj = ThirdPartyQuery(self.xty_url, cookie)
            ret = third_obj.quest_travel(request_data, token, captcha)
            if ret[0]:
                return '200', ret[1]
            return '400', ''
        except BaseException as e:
            return '400', ''


app = XtyApp()


@app.get("/get/xtyCaptcha")
def get_captcha_png():
    try:
        ret = app.get_captcha_png()
        if ret[0] != '200':
            return app.get_captcha_result[ret[0]]
        response = FileResponse(ret[1], media_type="image/png")
        response.set_cookie(key='x_captcha_token_key', value=ret[2])
        return response
    except BaseException as e:
        return app.get_captcha_result["400"]


@app.post("/get/travel")
async def quest_travel(travel_data: TravelData, x_captcha_token_key: Optional[str] = Cookie(None)):
    try:
        captcha = travel_data.captcha
        request_data = travel_data.data
        token = x_captcha_token_key
        ret = app.quest_travel(token, request_data, captcha)
        if ret[0] != '200':
            return app.get_captcha_result[ret[0]]
        return {"code": 200, "msg": "", "data": ret[1]}
    except BaseException as e:
        return app.get_captcha_result["400"]


if __name__ == '__main__':
    uvicorn.run(app='server:app', host='172.30.6.18', port=8080, workers=1)
