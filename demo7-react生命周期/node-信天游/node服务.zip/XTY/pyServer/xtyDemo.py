# -*- coding: utf-8 -*-
from aUtilsGov import *


class ThirdPartyQuery(TaxGov):
    def __init__(self, url, cookie):
        super(ThirdPartyQuery, self).__init__()
        self._cookie = cookie
        self.node_url = 'http://127.0.0.1'
        self.xty_url = url

    def init_third_website(self):
        url = self.xty_url
        try:
            r = self.getRedirects(url)
            if r[0] is True:
                return True
            return ''
        except Exception as e:
            return False

    def get_captcha_png(self):
        try:
            url = self.xty_url + '/tsky/captcha'
            main_dir = os.getcwd()
            png_path = os.path.join(main_dir, "captcha.png")
            r = self.saveImgByGetXty(url=url, localFile=png_path)
            if r[0] is True:
                return True, png_path, r[2]
            return False, '', ''
        except Exception as e:
            return False, '', ''

    def request_travel(self, quest_data, captcha_token, captcha_value):
        try:
            url = self.xty_url + "/tsky/tsky/validator"
            headers = copy.copy(jsonHeaders())
            headers['x-captcha-token-key'] = captcha_token
            headers['x-captcha-token-value'] = captcha_value
            headers['Origin'] = self.xty_url
            headers['Referer'] = self.xty_url + '/'
            r = self.postRequest(url=url, rqData=quest_data, qrHeaders=headers)
            if r[0] is True:
                return True, r[1]
            return False, ''
        except Exception as e:
            return e

    def quest_travel(self, quest_data, captcha_token, captcha_value):
        try:
            # 加密
            url = self.node_url + ':8888'
            data = {
                'eticketNo': quest_data.eticketNo,
                'invoiceNo': quest_data.invoiceNo,
                'price': quest_data.price,
                'passengerName': quest_data.passengerName,
            }
            rep = requests.post(url, data=data)
            if rep.status_code != 200:
                return '503', "加密失败"
            request_data = json.loads(rep.text)['data']
            print(request_data)
            req = self.request_travel(request_data, captcha_token, captcha_value)
            # 解密
            req = {
                'data': req
            }
            url = self.node_url + ':8880'
            rep = requests.post(url, data=req)
            if rep.status_code != 200:
                return '504', "解密密失败"
            return "200", rep.text
        except Exception as e:
            return '400', "服务异常"
