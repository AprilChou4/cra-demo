(function(t) {
    function e(e) {
        for (var s, r, o = e[0], c = e[1], l = e[2], v = 0, d = []; v < o.length; v++)
            r = o[v],
            Object.prototype.hasOwnProperty.call(a, r) && a[r] && d.push(a[r][0]),
            a[r] = 0;
        for (s in c)
            Object.prototype.hasOwnProperty.call(c, s) && (t[s] = c[s]);
        u && u(e);
        while (d.length)
            d.shift()();
        return n.push.apply(n, l || []),
        i()
    }
    function i() {
        for (var t, e = 0; e < n.length; e++) {
            for (var i = n[e], s = !0, o = 1; o < i.length; o++) {
                var c = i[o];
                0 !== a[c] && (s = !1)
            }
            s && (n.splice(e--, 1),
            t = r(r.s = i[0]))
        }
        return t
    }
    var s = {}
      , a = {
        app: 0
    }
      , n = [];
    function r(e) {
        if (s[e])
            return s[e].exports;
        var i = s[e] = {
            i: e,
            l: !1,
            exports: {}
        };
        return t[e].call(i.exports, i, i.exports, r),
        i.l = !0,
        i.exports
    }
    r.m = t,
    r.c = s,
    r.d = function(t, e, i) {
        r.o(t, e) || Object.defineProperty(t, e, {
            enumerable: !0,
            get: i
        })
    }
    ,
    r.r = function(t) {
        "undefined" !== typeof Symbol && Symbol.toStringTag && Object.defineProperty(t, Symbol.toStringTag, {
            value: "Module"
        }),
        Object.defineProperty(t, "__esModule", {
            value: !0
        })
    }
    ,
    r.t = function(t, e) {
        if (1 & e && (t = r(t)),
        8 & e)
            return t;
        if (4 & e && "object" === typeof t && t && t.__esModule)
            return t;
        var i = Object.create(null);
        if (r.r(i),
        Object.defineProperty(i, "default", {
            enumerable: !0,
            value: t
        }),
        2 & e && "string" != typeof t)
            for (var s in t)
                r.d(i, s, function(e) {
                    return t[e]
                }
                .bind(null, s));
        return i
    }
    ,
    r.n = function(t) {
        var e = t && t.__esModule ? function() {
            return t["default"]
        }
        : function() {
            return t
        }
        ;
        return r.d(e, "a", e),
        e
    }
    ,
    r.o = function(t, e) {
        return Object.prototype.hasOwnProperty.call(t, e)
    }
    ,
    r.p = "/";
    var o = window["webpackJsonp"] = window["webpackJsonp"] || []
      , c = o.push.bind(o);
    o.push = e,
    o = o.slice();
    for (var l = 0; l < o.length; l++)
        e(o[l]);
    var u = c;
    n.push([0, "chunk-vendors"]),
    i()
}
)({
    0: function(t, e, i) {
        t.exports = i("56d7")
    },
    "034f": function(t, e, i) {
        "use strict";
        var s = i("85ec")
          , a = i.n(s);
        a.a
    },
    "0ce7": function(t, e, i) {
        "use strict";
        var s = i("e6be")
          , a = i.n(s);
        a.a
    },
    "0d93": function(t, e, i) {},
    1: function(t, e) {},
    10: function(t, e) {},
    11: function(t, e) {},
    12: function(t, e) {},
    13: function(t, e) {},
    14: function(t, e) {},
    15: function(t, e) {},
    2: function(t, e) {},
    2960: function(t, e, i) {},
    3: function(t, e) {},
    "3efc": function(t, e, i) {
        "use strict";
        var s = i("cc60")
          , a = i.n(s);
        a.a
    },
    4: function(t, e) {},
    "49fa": function(t, e, i) {},
    "4db7": function(t, e, i) {
        "use strict";
        var s = i("f75b")
          , a = i.n(s);
        a.a
    },
    "4eed": function(t, e, i) {
        "use strict";
        var s = i("49fa")
          , a = i.n(s);
        a.a
    },
    5: function(t, e) {},
    "56d7": function(t, e, i) {
        "use strict";
        i.r(e);
        i("e260"),
        i("e6cf"),
        i("cca6"),
        i("a79d");
        var s, a, n = i("2b0e"), r = function() {
            var t = this
              , e = t.$createElement
              , i = t._self._c || e;
            return i("div", {
                attrs: {
                    id: "app"
                }
            }, [i("router-view")], 1)
        }, o = [], c = {
            name: "App"
        }, l = c, u = (i("034f"),
        i("2877")), v = Object(u["a"])(l, r, o, !1, null, null, null), d = v.exports, p = i("8c4f"), m = function() {
            var t = this
              , e = t.$createElement
              , i = t._self._c || e;
            return i("div", {
                staticClass: "index"
            }, [i("div", {
                staticClass: "g-body"
            }, [i("headerView"), i("div", {
                staticClass: "g-mn"
            }, [i("transition", {
                attrs: {
                    name: "error-fade"
                }
            }, [t.isActive ? i("div", {
                staticClass: "m-err"
            }, [i("div", {
                staticClass: "u-err "
            }, [i("div", {
                staticClass: "u-icon"
            }, [i("span", {
                staticClass: "icon-close"
            })]), i("span", [t._v(t._s(t.msg))])])]) : t._e()]), i("div", {
                staticClass: "g-mn-top"
            }, [t.renderData.showResult ? [i("itinerary", {
                attrs: {
                    ticketInfo: t.ticketInfo
                },
                on: {
                    close: t.close
                }
            })] : [i("indexMainView", {
                ref: "indexMainView",
                attrs: {
                    validateForm: t.validateForm
                },
                on: {
                    validate: t.validate
                }
            })]], 2), i("questionView")], 1), i("footerView")], 1)])
        }, f = [], h = i("5530"), g = function() {
            var t = this
              , e = t.$createElement
              , i = t._self._c || e;
            return i("div", {
                staticClass: "headerView"
            }, [i("div", {
                staticClass: "g-header-ct"
            }, [i("router-link", {
                attrs: {
                    to: "/"
                }
            }, [i("div", {
                staticClass: "m-logo"
            })]), i("div", {
                staticClass: "m-language"
            }, [t._m(0), t._m(1), i("div", {
                staticClass: "u-right",
                on: {
                    mouseover: function(e) {
                        return t.show()
                    }
                }
            }, [i("span", {
                staticClass: "icon-down"
            })]), i("div", {
                directives: [{
                    name: "show",
                    rawName: "v-show",
                    value: t.isShow,
                    expression: "isShow"
                }],
                staticClass: "m-select",
                on: {
                    mouseover: function(e) {
                        return t.show()
                    },
                    mouseleave: function(e) {
                        return t.hide()
                    }
                }
            }, [i("div", {
                staticClass: "u-cn",
                on: {
                    click: function(e) {
                        return t.hide()
                    }
                }
            }, [i("span", [t._v("简体中文")]), i("div", {
                staticClass: "u-icon"
            })]), t._m(2)])])], 1)])
        }, _ = [function() {
            var t = this
              , e = t.$createElement
              , i = t._self._c || e;
            return i("div", {
                staticClass: "u-left"
            }, [i("span", {
                staticClass: "icon-language"
            })])
        }
        , function() {
            var t = this
              , e = t.$createElement
              , i = t._self._c || e;
            return i("div", {
                staticClass: "u-mid"
            }, [i("span", [t._v("简体中文")])])
        }
        , function() {
            var t = this
              , e = t.$createElement
              , i = t._self._c || e;
            return i("div", {
                staticClass: "u-en"
            }, [i("span", [t._v("English")])])
        }
        ], C = {
            name: "headerView",
            data: function() {
                return {
                    isShow: !1
                }
            },
            methods: {
                show: function() {
                    var t = this;
                    t.isShow = !0
                },
                hide: function() {
                    var t = this;
                    t.isShow = !1
                }
            }
        }, w = C, A = (i("4eed"),
        Object(u["a"])(w, g, _, !1, null, "2e75fc88", null)), I = A.exports, T = function() {
            var t = this
              , e = t.$createElement;
            t._self._c;
            return t._m(0)
        }, E = [function() {
            var t = this
              , e = t.$createElement
              , i = t._self._c || e;
            return i("div", {
                staticClass: "footerView"
            }, [i("div", {
                staticClass: "g-footer-ct"
            }, [i("div", {
                staticClass: "m-left"
            }, [i("div", {
                staticClass: "u-item"
            }, [i("a", {
                staticClass: "u-link",
                attrs: {
                    href: "http://beian.miit.gov.cn",
                    target: "_blank"
                }
            }, [t._v("京ICP备06014661号-1")])]), i("div", {
                staticClass: "u-item"
            }, [i("span", [t._v("京ICP证060566号")])]), i("div", {
                staticClass: "u-item"
            }, [i("span", [t._v("京公网安备11010102000528号")])])]), i("div", {
                staticClass: "m-right"
            }, [i("div", {
                staticClass: "u-icon"
            }, [i("span", [t._v("©")])]), i("div", {
                staticClass: "u-msg"
            }, [i("span", [t._v("2020 All Rights Reserved. Privacy Policy")])])])])])
        }
        ], y = {
            name: "footerView"
        }, P = y, x = (i("6b55"),
        Object(u["a"])(P, T, E, !1, null, "2e586628", null)), b = x.exports, N = function() {
            var t = this
              , e = t.$createElement
              , i = t._self._c || e;
            return i("div", {
                staticClass: "indexMainView"
            }, [i("div", {
                staticClass: "m-left"
            }, [i("searchFormView", {
                ref: "searchFormView",
                attrs: {
                    validateForm: t.validateForm
                },
                on: {
                    validate: t.validate
                }
            })], 1), t._m(0)])
        }, O = [function() {
            var t = this
              , e = t.$createElement
              , s = t._self._c || e;
            return s("div", {
                staticClass: "m-right"
            }, [s("img", {
                attrs: {
                    src: i("faeb")
                }
            })])
        }
        ], D = function() {
            var t = this
              , e = t.$createElement
              , i = t._self._c || e;
            return i("div", {
                staticClass: "searchFormView"
            }, [t._m(0), i("div", {
                staticClass: "u-ct"
            }, [i("div", {
                staticClass: "u-item"
            }, [t._m(1), i("div", {
                staticClass: "u-input"
            }, [i("input", {
                class: [t.validateInfo.isIrnoPass ? "u-text" : "u-text-err"],
                attrs: {
                    type: "text",
                    placeholder: "行程单印刷序号 如 1234567890 1",
                    maxlength: "12"
                },
                on: {
                    input: function(e) {
                        return t.watchIrnoEdit(e.target)
                    }
                }
            }), t.irnoEdit ? [i("div", {
                class: [t.validateInfo.isIrnoPass ? "u-icon" : "u-icon-err"]
            }, [i("span", {
                staticClass: "icon-edit"
            })])] : t._e(), t.validateInfo.isIrnoPass ? t._e() : [i("div", {
                directives: [{
                    name: "show",
                    rawName: "v-show",
                    value: t.showIrnoTip,
                    expression: "showIrnoTip"
                }],
                staticClass: "u-form-err"
            }, [i("div", {
                staticClass: "u-icon1",
                on: {
                    click: function(e) {
                        return t.close("irno")
                    }
                }
            }, [i("span", {
                staticClass: "icon-close"
            })]), i("span", [t._v("行程单号" + t._s(t.validateInfo.irnomsg))])])]], 2)]), i("div", {
                staticClass: "u-item"
            }, [t._m(2), i("div", {
                staticClass: "u-input"
            }, [i("input", {
                directives: [{
                    name: "model",
                    rawName: "v-model",
                    value: t.renderData.passengerName,
                    expression: "renderData.passengerName"
                }],
                class: [t.validateInfo.isPsgPass ? "u-text" : "u-text-err"],
                attrs: {
                    type: "text",
                    placeholder: "旅客姓名 如张三或 ZHANG/SAN MR",
                    maxlength: "30"
                },
                domProps: {
                    value: t.renderData.passengerName
                },
                on: {
                    input: [function(e) {
                        e.target.composing || t.$set(t.renderData, "passengerName", e.target.value)
                    }
                    , t.watchPsgEdit]
                }
            }), t.psgEdit ? [i("div", {
                class: [t.validateInfo.isPsgPass ? "u-icon" : "u-icon-err"]
            }, [i("span", {
                staticClass: "icon-edit"
            })])] : t._e(), t.validateInfo.isPsgPass ? t._e() : [i("div", {
                directives: [{
                    name: "show",
                    rawName: "v-show",
                    value: t.showPsgTip,
                    expression: "showPsgTip"
                }],
                staticClass: "u-form-err"
            }, [i("div", {
                staticClass: "u-icon1",
                on: {
                    click: function(e) {
                        return t.close("psg")
                    }
                }
            }, [i("span", {
                staticClass: "icon-close"
            })]), i("span", [t._v("旅客姓名" + t._s(t.validateInfo.psgmsg))])])]], 2)]), i("div", {
                staticClass: "u-item"
            }, [t._m(3), i("div", {
                staticClass: "u-input"
            }, [i("input", {
                class: [t.validateInfo.isEtnoPass ? "u-text" : "u-text-err"],
                attrs: {
                    type: "text",
                    placeholder: "请输入13位数字，如 999-1111111111",
                    maxlength: "14"
                },
                on: {
                    input: function(e) {
                        return t.watchEtnoEdit(e.target)
                    }
                }
            }), t.etnoEdit ? [i("div", {
                class: [t.validateInfo.isEtnoPass ? "u-icon" : "u-icon-err"]
            }, [i("span", {
                staticClass: "icon-edit"
            })])] : t._e(), t.validateInfo.isEtnoPass ? t._e() : [i("div", {
                directives: [{
                    name: "show",
                    rawName: "v-show",
                    value: t.showEtnoTip,
                    expression: "showEtnoTip"
                }],
                staticClass: "u-form-err"
            }, [i("div", {
                staticClass: "u-icon1",
                on: {
                    click: function(e) {
                        return t.close("etno")
                    }
                }
            }, [i("span", {
                staticClass: "icon-close"
            })]), i("span", [t._v("票号" + t._s(t.validateInfo.etnomsg))])])]], 2)]), i("div", {
                staticClass: "u-item"
            }, [t._m(4), i("div", {
                staticClass: "u-input"
            }, [i("input", {
                directives: [{
                    name: "model",
                    rawName: "v-model",
                    value: t.renderData.price,
                    expression: "renderData.price"
                }],
                class: [t.validateInfo.isPricePass ? "u-text" : "u-text-err"],
                attrs: {
                    type: "text",
                    placeholder: "请输入合计/总价",
                    maxlength: "30"
                },
                domProps: {
                    value: t.renderData.price
                },
                on: {
                    input: [function(e) {
                        e.target.composing || t.$set(t.renderData, "price", e.target.value)
                    }
                    , t.watchPriceEdit]
                }
            }), t.priceEdit ? [i("div", {
                class: [t.validateInfo.isPricePass ? "u-icon" : "u-icon-err"]
            }, [i("span", {
                staticClass: "icon-edit"
            })])] : t._e(), t.validateInfo.isPricePass ? t._e() : [i("div", {
                directives: [{
                    name: "show",
                    rawName: "v-show",
                    value: t.showPriceTip,
                    expression: "showPriceTip"
                }],
                staticClass: "u-form-err"
            }, [i("div", {
                staticClass: "u-icon1",
                on: {
                    click: function(e) {
                        return t.close("price")
                    }
                }
            }, [i("span", {
                staticClass: "icon-close"
            })]), i("span", [t._v("合计总价" + t._s(t.validateInfo.pricemsg))])])]], 2)]), i("div", {
                staticClass: "u-item"
            }, [t._m(5), i("div", {
                staticClass: "u-item2"
            }, [i("div", {
                staticClass: "u-input2"
            }, [i("input", {
                directives: [{
                    name: "model",
                    rawName: "v-model",
                    value: t.renderData.verificationCode,
                    expression: "renderData.verificationCode"
                }],
                class: [t.validateInfo.isCodePass ? "u-text2" : "u-text2-err"],
                attrs: {
                    type: "text",
                    placeholder: "请输入计算结果",
                    maxlength: "6"
                },
                domProps: {
                    value: t.renderData.verificationCode
                },
                on: {
                    input: function(e) {
                        e.target.composing || t.$set(t.renderData, "verificationCode", e.target.value)
                    }
                }
            }), i("div", {
                staticClass: "u-captcha"
            }, [i("captcha", {
                ref: "captcha",
                on: {
                    refreshCaptchaToken: t.refreshCaptchaToken
                }
            })], 1), t.validateInfo.isCodePass ? t._e() : [i("div", {
                directives: [{
                    name: "show",
                    rawName: "v-show",
                    value: t.showCodeTip,
                    expression: "showCodeTip"
                }],
                staticClass: "u-form-err"
            }, [i("div", {
                staticClass: "u-icon1",
                on: {
                    click: function(e) {
                        return t.close("code")
                    }
                }
            }, [i("span", {
                staticClass: "icon-close"
            })]), i("span", [t._v("验证码" + t._s(t.validateInfo.codemsg))])])]], 2)])]), i("div", {
                staticClass: "u-btn",
                on: {
                    click: function(e) {
                        return t.validate()
                    }
                }
            }, [i("span", [t._v("开始验真")])])]), t._m(6)])
        }, k = [function() {
            var t = this
              , e = t.$createElement
              , i = t._self._c || e;
            return i("div", {
                staticClass: "u-title"
            }, [i("div", {
                staticClass: "u-item1"
            }, [i("span", [t._v("行程单验真")])]), i("div", {
                staticClass: "u-item2"
            }, [i("span", [t._v("此网站只验证行程单真伪，不能打印行程单，不作为正规报销凭证")])])])
        }
        , function() {
            var t = this
              , e = t.$createElement
              , i = t._self._c || e;
            return i("div", {
                staticClass: "u-tip"
            }, [i("span", [t._v("行程单号")])])
        }
        , function() {
            var t = this
              , e = t.$createElement
              , i = t._self._c || e;
            return i("div", {
                staticClass: "u-tip"
            }, [i("span", [t._v("旅客姓名")])])
        }
        , function() {
            var t = this
              , e = t.$createElement
              , i = t._self._c || e;
            return i("div", {
                staticClass: "u-tip"
            }, [i("span", [t._v("电子客票号")])])
        }
        , function() {
            var t = this
              , e = t.$createElement
              , i = t._self._c || e;
            return i("div", {
                staticClass: "u-tip"
            }, [i("span", [t._v("合计总价")])])
        }
        , function() {
            var t = this
              , e = t.$createElement
              , i = t._self._c || e;
            return i("div", {
                staticClass: "u-tip"
            }, [i("span", [t._v("验证码")])])
        }
        , function() {
            var t = this
              , e = t.$createElement
              , i = t._self._c || e;
            return i("div", {
                staticClass: "u-foot"
            }, [i("div", {
                staticClass: "u-top"
            }, [i("div", {
                staticClass: "u-item"
            }, [i("span", [t._v("三方验真平台：")])]), i("div", {
                staticClass: "u-item"
            }, [i("a", {
                staticClass: "ref",
                attrs: {
                    target: "_blank",
                    href: "https://extra.csair.com/content/checkTicket/index.html?lang=zh#/search"
                }
            }, [t._v(" 南方航空 ")])]), i("div", {
                staticClass: "u-item"
            }, [i("a", {
                staticClass: "ref",
                attrs: {
                    target: "_blank",
                    href: "http://flights.ch.com/show-check-ticket"
                }
            }, [t._v("春秋航空")])]), i("div", {
                staticClass: "u-item"
            }, [i("a", {
                staticClass: "ref",
                attrs: {
                    target: "_blank",
                    href: "http://www.9air.com/ticketconfirm.html"
                }
            }, [t._v("九元航空")])])])])
        }
        ], S = (i("a15b"),
        i("a434"),
        i("ac1f"),
        i("5319"),
        i("1276"),
        function() {
            var t = this
              , e = t.$createElement
              , i = t._self._c || e;
            return i("img", {
                attrs: {
                    src: t.src
                },
                on: {
                    click: t.refresh
                }
            })
        }
        ), F = [], V = (i("13d5"),
        i("ace4"),
        i("d3b7"),
        i("5cc6"),
        i("9a8c"),
        i("a975"),
        i("735e"),
        i("c1ac"),
        i("d139"),
        i("3a7b"),
        i("d5d6"),
        i("82f8"),
        i("e91f"),
        i("60bd"),
        i("5f96"),
        i("3280"),
        i("3fcc"),
        i("ca91"),
        i("25a1"),
        i("cd26"),
        i("3c5d"),
        i("2954"),
        i("649e"),
        i("219c"),
        i("170b"),
        i("b39a"),
        i("72f7"),
        i("25f0"),
        i("3ca3"),
        i("ddb0"),
        i("2b3d"),
        i("2909")), j = i("bc3a"), R = i.n(j), G = i("94f8"), q = i.n(G), L = i("1132"), K = i.n(L), M = i("640f"), Q = i.n(M), J = i("f8d5"), B = i.n(J), U = i("6d08"), W = i.n(U), Z = i("c198"), H = i.n(Z), $ = {
            baseURL: "/tsky",
            timeout: 6e4
        }, X = B.a.parse("GP09101ABEAUITGP"), Y = B.a.parse("0123456789ABCDEF");
        function z(t) {
            return t instanceof URLSearchParams ? t.toString() : t instanceof String || "string" == typeof t ? t : JSON.stringify(t)
        }
        var tt, et, it = [function(t) {
            if (t.aes) {
                var e = H.a.encrypt(JSON.stringify(t.data), X, {
                    iv: Y
                });
                t.data = e.ciphertext.toString(Q.a)
            }
            if (t.hash) {
                var i = q()(z(t.data))
                  , s = t.data;
                t.data = {
                    hash: i.toString(K.a),
                    data: s
                }
            }
            return t
        }
        , function(t) {
            return Promise.reject(t)
        }
        ], st = [function(t) {
            if (t.config.aes) {
                var e = H.a.decrypt(t.data, X, {
                    iv: Y,
                    format: W.a
                })
                  , i = e.toString(B.a)
                  , s = JSON.parse(i);
                t.data = s
            }
            return t
        }
        , function(t) {
            return Promise.reject(t)
        }
        ];
        tt = it,
        et = st;
        var at = R.a.create($);
        (s = at.interceptors.request).use.apply(s, Object(V["a"])(tt)),
        (a = at.interceptors.response).use.apply(a, Object(V["a"])(et));
        var nt = i("560f")
          , rt = i.n(nt);
        function ot() {
            var t = "/captcha";
            return at.get(t, {
                headers: {
                    "If-Modified-Since": "0",
                    Accept: "image/png"
                },
                responseType: "arraybuffer"
            })
        }
        function ct(t) {
            var e = "/tsky/validator"
              , i = rt.a.get("x-captcha-token-key")
              , s = t.verificationCode
              , a = {
                eticketNo: t.eticketNo,
                invoiceNo: t.invoiceNo,
                price: t.price,
                passengerName: t.passengerName
            };
            return at.post(e, a, {
                hash: !0,
                aes: !0,
                headers: {
                    Accept: "text/plain",
                    "x-captcha-token-key": i,
                    "x-captcha-token-value": s
                }
            })
        }
        function lt(t) {
            var e = "/tsky/pcValidatorByCaac"
              , i = rt.a.get("x-captcha-token-key")
              , s = t.verificationCode
              , a = {
                eticketNo: t.eticketNo,
                invoiceNo: t.invoiceNo,
                price: t.price,
                passengerName: t.passengerName
            };
            return at.post(e, a, {
                hash: !0,
                aes: !0,
                headers: {
                    Accept: "text/plain",
                    "x-captcha-token-key": i,
                    "x-captcha-token-value": s
                }
            })
        }
        var ut = {
            data: function() {
                return {
                    src: ""
                }
            },
            name: "captcha",
            methods: {
                refresh: function() {
                    var t = this;
                    ot().then((function(e) {
                        t.$emit("refreshCaptchaToken", e.headers["x-captcha-token-key"]),
                        t.src = "data:image/png;base64," + btoa(new Uint8Array(e.data).reduce((function(t, e) {
                            return t + String.fromCharCode(e)
                        }
                        ), ""))
                    }
                    ))
                }
            },
            created: function() {
                this.refresh()
            }
        }
          , vt = ut
          , dt = Object(u["a"])(vt, S, F, !1, null, "bf005dec", null)
          , pt = dt.exports
          , mt = {
            components: {
                captcha: pt
            },
            name: "searchFormView",
            props: {
                validateForm: {
                    type: Object,
                    default: function() {}
                }
            },
            data: function() {
                return {
                    irnoEdit: !1,
                    psgEdit: !1,
                    etnoEdit: !1,
                    priceEdit: !1,
                    showIrnoTip: !0,
                    showPsgTip: !0,
                    showEtnoTip: !0,
                    showPriceTip: !0,
                    showCodeTip: !0,
                    isAdd: !0,
                    addSpace: !0
                }
            },
            methods: {
                refreshCaptchaToken: function(t) {
                    rt.a.set({
                        "x-captcha-token-key": t
                    })
                },
                refreshCaptchaImg: function() {
                    this.$refs.captcha.refresh()
                },
                validate: function() {
                    var t = this;
                    t.showIrnoTip = !0,
                    t.showPsgTip = !0,
                    t.showEtnoTip = !0,
                    t.showPriceTip = !0,
                    t.showCodeTip = !0,
                    this.$emit("validate", t.renderData)
                },
                validateIrno: function() {
                    var t = this;
                    this.$emit("validateIrno", t.renderData.invoiceNo)
                },
                watchIrnoEdit: function(t) {
                    var e = t.value
                      , i = !1;
                    e = e.split("");
                    for (var s = 0; s < e.length; s++)
                        " " === e[s] && (i = !0);
                    e.length <= 10 && (this.addSpace = !0),
                    this.renderData.invoiceNo != t.value && (this.addSpace = !0),
                    e.length > 10 && this.addSpace && !i && (e.splice(10, 0, " "),
                    this.addSpace = !1),
                    t.value = e.join(""),
                    this.renderData.invoiceNo = e.join(""),
                    this.renderData.invoiceNo = this.renderData.invoiceNo.replace(/\s+/g, "");
                    var a = this;
                    a.irnoEdit = !0,
                    0 === a.renderData.invoiceNo.length && (a.irnoEdit = !1),
                    this.$emit("validateIrno", a.renderData.invoiceNo)
                },
                watchEtnoEdit: function(t) {
                    var e = t.value
                      , i = !1;
                    e = e.split("");
                    for (var s = 0; s < e.length; s++)
                        "-" === e[s] && (i = !0);
                    e.length <= 3 && (this.isAdd = !0,
                    t.value = e.join("")),
                    this.renderData.eticketNo != t.value && (this.isAdd = !0),
                    e.length > 3 && this.isAdd && !i && (e.splice(3, 0, "-"),
                    this.isAdd = !1),
                    t.value = e.join(""),
                    this.renderData.eticketNo = e.join("");
                    var a = this;
                    a.etnoEdit = !0,
                    0 === a.renderData.eticketNo.length && (a.etnoEdit = !1)
                },
                watchPsgEdit: function() {
                    var t = this;
                    t.psgEdit = !0,
                    0 === t.renderData.passengerName.length && (t.psgEdit = !1)
                },
                watchPriceEdit: function() {
                    var t = this;
                    t.priceEdit = !0,
                    0 === t.renderData.price.length && (t.priceEdit = !1)
                },
                close: function(t) {
                    var e = this;
                    "irno" === t ? e.showIrnoTip = !1 : "psg" === t ? e.showPsgTip = !1 : "etno" === t ? e.showEtnoTip = !1 : "price" === t ? e.showPriceTip = !1 : "code" === t && (e.showCodeTip = !1)
                }
            },
            computed: {
                renderData: function() {
                    return this.validateForm.validateForm
                },
                validateInfo: function() {
                    return this.validateForm.validateInfo
                }
            }
        }
          , ft = mt
          , ht = (i("75d0"),
        Object(u["a"])(ft, D, k, !1, null, "0f16cc84", null))
          , gt = ht.exports
          , _t = {
            components: {
                searchFormView: gt
            },
            name: "indexMainView",
            props: {
                validateForm: {
                    type: Object,
                    default: function() {}
                }
            },
            methods: {
                validate: function(t) {
                    this.$emit("validate", t)
                },
                refreshCaptchaImg: function() {
                    this.$refs.searchFormView.refreshCaptchaImg()
                }
            }
        }
          , Ct = _t
          , wt = (i("0ce7"),
        Object(u["a"])(Ct, N, O, !1, null, "124d685e", null))
          , At = wt.exports
          , It = function() {
            var t = this
              , e = t.$createElement
              , i = t._self._c || e;
            return i("div", {
                staticClass: "questionView"
            }, [i("div", {
                staticClass: "g-mn-ctbottom"
            }, [i("div", {
                staticClass: "m-left"
            }, [t._m(0), i("router-link", {
                attrs: {
                    to: "/question"
                }
            }, [i("div", {
                staticClass: "u-bottom"
            }, [i("span", [t._v("查看更多")])])])], 1), t._m(1)])])
        }
          , Tt = [function() {
            var t = this
              , e = t.$createElement
              , i = t._self._c || e;
            return i("div", {
                staticClass: "u-top"
            }, [i("span", [t._v("常见问题")])])
        }
        , function() {
            var t = this
              , e = t.$createElement
              , i = t._self._c || e;
            return i("div", {
                staticClass: "m-right"
            }, [i("div", {
                staticClass: "u-item"
            }, [i("div", {
                staticClass: "u-title"
            }, [i("div", {
                staticClass: "u-icon"
            }, [i("span", {
                staticClass: "icon-question"
            })]), i("span", [t._v("可以查验行程单的时间范围？")])]), i("div", {
                staticClass: "u-ct"
            }, [i("div", {
                staticClass: "u-icon"
            }, [i("div", {
                staticClass: "u-arrow"
            })]), i("div", {
                staticClass: "u-msg"
            }, [i("span", [t._v("行程单开具后到客票使用后三年内。")])])])]), i("div", {
                staticClass: "u-item"
            }, [i("div", {
                staticClass: "u-title"
            }, [i("div", {
                staticClass: "u-icon"
            }, [i("span", {
                staticClass: "icon-question"
            })]), i("div", {
                staticClass: "u-msg"
            }, [i("span", [t._v("其他查验网站？")])])]), i("div", {
                staticClass: "u-ct"
            }, [i("div", {
                staticClass: "u-icon"
            }, [i("div", {
                staticClass: "u-arrow"
            })]), i("div", {
                staticClass: "u-msg"
            }, [i("span", [t._v("春秋、九元、南航客票的报销凭证，可分别访问春秋官网、九元官网、南航官网进行查验。")])])])]), i("div", {
                staticClass: "u-item"
            }, [i("div", {
                staticClass: "u-title"
            }, [i("div", {
                staticClass: "u-icon"
            }, [i("span", {
                staticClass: "icon-question"
            })]), i("div", {
                staticClass: "u-msg"
            }, [i("span", [t._v("电话验真流程？")])])]), i("div", {
                staticClass: "u-ct"
            }, [i("div", {
                staticClass: "u-icon"
            }, [i("div", {
                staticClass: "u-arrow"
            })]), i("div", {
                staticClass: "u-msg"
            }, [i("span", [t._v("拨通400-815-8888后，依次按提示输入电子客票号及行程单号，自动告知验真结果。")])])])])])
        }
        ]
          , Et = {
            name: "questionView"
        }
          , yt = Et
          , Pt = (i("95f9"),
        Object(u["a"])(yt, It, Tt, !1, null, "7754767f", null))
          , xt = Pt.exports
          , bt = function() {
            var t = this
              , e = t.$createElement
              , i = t._self._c || e;
            return i("div", {
                staticClass: "itinerary"
            }, [i("div", {
                staticClass: "m-tip"
            }, [i("span", [t._v(t._s(t.renderData.passenger.name) + " 您好")])]), i("itineraryView", {
                attrs: {
                    itinerary: t.renderData
                }
            }), i("div", {
                staticClass: "m-btn",
                on: {
                    click: function(e) {
                        return t.close()
                    }
                }
            }, [i("span", [t._v("关闭")])])], 1)
        }
          , Nt = []
          , Ot = function() {
            var t = this
              , e = t.$createElement
              , i = t._self._c || e;
            return i("div", {
                staticClass: "itinerary-view"
            }, [i("div", {
                staticClass: "m-top"
            }, [i("div", {
                staticClass: "u-item"
            }, ["1" == t.itinerary.status ? [i("span", [t._v("印刷编号：" + t._s(t.itinerary.serialNumber) + " " + t._s(t.itinerary.mod))])] : "2" == t.itinerary.status ? [i("span", [t._v("印刷编号：作废")])] : [i("span", [t._v("印刷编号：未使用")])]], 2), i("div", {
                staticClass: "u-item"
            }, [i("span", [t._v("打印时间：" + t._s(t.itinerary.dateOfIssue))])]), i("div", {
                staticClass: "u-item"
            }, [i("span", ["1" == t.itinerary.status ? [i("span", [t._v("行程单已打印")])] : "2" == t.itinerary.status ? [i("span", [t._v("行程单作废")])] : [i("span", [t._v("行程单未打印")])]], 2)])]), i("ul", {
                staticClass: "m-itinerary"
            }, ["1" == t.itinerary.status ? [i("li", {
                staticClass: "u-itno"
            }, [i("div", {
                staticClass: "u-gp"
            }, [t._v(t._s(t.itinerary.gP))]), i("div", {
                staticClass: "u-it"
            }, [t._v(t._s(t.itinerary.serialNumber) + " " + t._s(t.itinerary.mod))])])] : "2" == t.itinerary.status ? [i("li", {
                staticClass: "u-itno"
            }, [i("div", {
                staticClass: "u-gp"
            }, [t._v(t._s(t.itinerary.gP))]), i("div", {
                staticClass: "u-it"
            }, [t._v("作废")])])] : [i("li", {
                staticClass: "u-itno"
            }, [i("div", {
                staticClass: "u-gp"
            }, [t._v(t._s(t.itinerary.gP))]), i("div", {
                staticClass: "u-it"
            }, [t._v("未使用")])])], t._m(0), i("li", {
                staticClass: "u-passenger"
            }, [i("span", [t._v(t._s(t.itinerary.passenger.name))]), i("span", [t._v(t._s(t.itinerary.passenger.id))]), i("span", [t._v(t._s(t.itinerary.passenger.endorsements))])]), t._m(1), i("li", {
                staticClass: "u-journeydet"
            }, [i("table", [i("tbody", {
                staticClass: "u-journey"
            }, t._l(t.itinerary.journeys, (function(e) {
                return i("tr", {
                    key: e.seq
                }, [i("td", [i("p", [t._v(t._s(e.airport.terminal))])]), i("td", [i("p", [t._v(t._s(e.airport.city))])]), i("td", [i("p", [t._v(t._s(e.airport.code))])]), i("td", [i("p", [t._v(t._s(e.carrier))])]), i("td", [i("p", [t._v(t._s(e.flight))])]), i("td", [i("p", [t._v(t._s(e.flightClass))])]), i("td", [i("p", [t._v(t._s(e.date))])]), i("td", [i("p", [t._v(t._s(e.time))])]), i("td", [i("p", [t._v(t._s(e.fareBasis))])]), i("td", [i("p", [t._v(t._s(e.notValidBefore))])]), i("td", [i("p", [t._v(t._s(e.notValidAfter))])]), i("td", [i("p", [t._v(t._s(e.allow))])])])
            }
            )), 0), i("tfoot", {
                staticClass: "u-pricing"
            }, [i("tr", [i("td", {
                staticClass: "fare"
            }, [i("p", [t._v(" " + t._s(t.itinerary.pricing.fare) + " ")])]), i("td", [i("p", [t._v(t._s(t.itinerary.pricing.caacDevelopmentFund))])]), i("td", [i("p", [t._v(t._s(t.itinerary.pricing.fuelSurcharger))])]), i("td", [i("p", [t._v(t._s(t.itinerary.pricing.otherTaxes))])]), i("td", [i("p", [t._v(t._s(t.itinerary.pricing.total))])])])])])]), i("li", {
                staticClass: "u-foot1"
            }, [i("span", [t._v(" " + t._s(t.itinerary.eTicketNO)), i("br"), t._v(t._s(t.itinerary.rawRemark) + " ")]), i("span", [t._v(" " + t._s(t.itinerary.check) + " ")]), i("span", [t._v(t._s(t.itinerary.information))]), i("span", [t._v(t._s(t.itinerary.insurance))])]), i("li", {
                staticClass: "u-foot2"
            }, [i("span", [i("p", [t._v(t._s(t.itinerary.office))]), i("p", [t._v(t._s(t.itinerary.iata))])]), i("span", [i("br"), i("p", [t._v(t._s(t.itinerary.issueBy))])]), i("span", [i("br"), i("p", [t._v(t._s(t.itinerary.dateOfIssue))])])])], 2)])
        }
          , Dt = [function() {
            var t = this
              , e = t.$createElement
              , i = t._self._c || e;
            return i("li", {
                staticClass: "u-serialno"
            }, [i("p")])
        }
        , function() {
            var t = this
              , e = t.$createElement
              , i = t._self._c || e;
            return i("li", {
                staticClass: "u-pnrno"
            }, [i("span")])
        }
        ]
          , kt = {
            data: function() {
                return {}
            },
            components: {},
            name: "itineraryView",
            props: {
                itinerary: {
                    type: Object,
                    default: function() {}
                }
            },
            computed: {
                validItinery: function() {
                    return this.itinerary && this.itinerary.passenger,
                    !0
                }
            },
            methods: {}
        }
          , St = kt
          , Ft = (i("4db7"),
        Object(u["a"])(St, Ot, Dt, !1, null, "a3fdbb56", null))
          , Vt = Ft.exports
          , jt = {
            components: {
                itineraryView: Vt
            },
            name: "itinerary",
            props: {
                ticketInfo: {
                    type: Object,
                    default: function() {}
                }
            },
            data: function() {
                return {}
            },
            computed: {
                renderData: function() {
                    return this.ticketInfo
                }
            },
            methods: {
                close: function() {
                    this.$emit("close")
                }
            }
        }
          , Rt = jt
          , Gt = (i("e173"),
        Object(u["a"])(Rt, bt, Nt, !1, null, "82bf62ca", null))
          , qt = Gt.exports
          , Lt = i("2f62")
          , Kt = {
            components: {
                headerView: I,
                footerView: b,
                questionView: xt,
                indexMainView: At,
                itinerary: qt
            },
            name: "index",
            data: function() {
                return {
                    msg: "",
                    isActive: !1,
                    timer: null
                }
            },
            computed: Object(h["a"])(Object(h["a"])({}, Object(Lt["c"])("validateCtrl", ["GET_RENDER_DATA", "GET_VALIDATEFORM", "GET_TICKETINFO", "GET_VALIDATEINFO"])), {}, {
                renderData: function() {
                    return this["GET_RENDER_DATA"]
                },
                validateForm: function() {
                    return {
                        validateForm: this["GET_VALIDATEFORM"],
                        validateInfo: this["GET_VALIDATEINFO"]
                    }
                },
                ticketInfo: function() {
                    return this["GET_TICKETINFO"]
                }
            }),
            methods: Object(h["a"])(Object(h["a"])({}, Object(Lt["b"])("validateCtrl", ["DO_INIT_DATA", "DO_VALIDATE_ITI", "DO_UPDATE_SHOWRESULT", "DO_VALIDATE_IRNO"])), {}, {
                initData: function() {
                    this["DO_INIT_DATA"]().then((function() {}
                    )).catch((function() {}
                    ))
                },
                refreshCaptchaImg: function() {
                    this.$refs.indexMainView.refreshCaptchaImg()
                },
                handler: function() {
                    this.isActive = !1
                },
                validate: function(t) {
                    var e = this;
                    this["DO_VALIDATE_ITI"](t).then((function(t) {
                        var i = t.data;
                        i.success ? e.isActive = !1 : (e.msg = i.msg,
                        e.timer ? (clearTimeout(e.timer),
                        e.timer = setTimeout(e.handler, 2e3)) : e.timer = setTimeout(e.handler, 2e3),
                        e.isActive = !0),
                        e.refreshCaptchaImg()
                    }
                    )).catch((function(t) {
                        null !== t.msg && void 0 !== t.msg && (e.msg = t.msg,
                        e.timer ? (clearTimeout(e.timer),
                        e.timer = setTimeout(e.handler, 2e3)) : e.timer = setTimeout(e.handler, 2e3),
                        e.isActive = !0),
                        e.refreshCaptchaImg()
                    }
                    ))
                },
                close: function() {
                    var t = !1;
                    this["DO_UPDATE_SHOWRESULT"](t)
                }
            }),
            created: function() {
                this.initData()
            }
        }
          , Mt = Kt
          , Qt = (i("3efc"),
        Object(u["a"])(Mt, m, f, !1, null, "36a63c48", null))
          , Jt = Qt.exports
          , Bt = function() {
            var t = this
              , e = t.$createElement
              , i = t._self._c || e;
            return i("div", {
                staticClass: "question"
            }, [i("headerView"), i("div", {
                staticClass: "g-mn"
            }, [i("div", {
                staticClass: "g-mn-ct"
            }, [i("div", {
                staticClass: "m-list"
            }, [t._m(0), i("ul", {
                staticClass: "u-ct"
            }, t._l(t.questionList, (function(e, s) {
                return i("li", {
                    key: s,
                    staticClass: "u-item",
                    on: {
                        click: function(e) {
                            return t.getItem(s)
                        }
                    }
                }, [i("div", {
                    staticClass: "u-item-que"
                }, [i("span", [t._v(t._s(e.question))])]), i("div", {
                    directives: [{
                        name: "show",
                        rawName: "v-show",
                        value: t.activeClass == s,
                        expression: "activeClass == index ? true:false"
                    }],
                    staticClass: "u-item-ans"
                }, [i("span", [t._v(t._s(e.answer))])])])
            }
            )), 0)])])]), i("footerView")], 1)
        }
          , Ut = [function() {
            var t = this
              , e = t.$createElement
              , i = t._self._c || e;
            return i("div", {
                staticClass: "u-title"
            }, [i("span", [t._v("常见问题")])])
        }
        ]
          , Wt = {
            name: "question",
            components: {
                headerView: I,
                footerView: b
            },
            data: function() {
                return {
                    questionList: [{
                        question: "1.为什么需要安装证书？",
                        answer: "答：为了保证您的发票信息在互联网上的安全，查验平台通过税务根证书实现数据安全传输，保障发票信息不泄露，因此需要您正确安装根证书。"
                    }, {
                        question: "2.什么操作系统可以登录平台查验发票？",
                        answer: "答："
                    }, {
                        question: "3.查验平台支持什么浏览器？",
                        answer: "答："
                    }, {
                        question: "4.输入查验项之后，为什么不显示验证码？",
                        answer: "答："
                    }, {
                        question: "5.为什么首页或者查验结果页面显示不正常？",
                        answer: "答："
                    }, {
                        question: "6.可以查验什么类型的发票？",
                        answer: "答："
                    }, {
                        question: "7.可以查验发票的时间范围？",
                        answer: "答："
                    }, {
                        question: "8.为什么会显示“查无此票”？",
                        answer: "答："
                    }, {
                        question: "9.为什么提示“超过该张发票当天查验次数(请于次日再次查验)!”？",
                        answer: "答："
                    }, {
                        question: "10.点击查验按钮，为什么不弹出查验结果？",
                        answer: "答："
                    }, {
                        question: "11.验证码输入之后，查验按钮不可用，怎么办？",
                        answer: "答："
                    }, {
                        question: "12.查验平台支持手机查验吗？",
                        answer: "答："
                    }],
                    activeClass: -1
                }
            },
            methods: {
                getItem: function(t) {
                    this.activeClass = t
                }
            }
        }
          , Zt = Wt
          , Ht = (i("b166"),
        Object(u["a"])(Zt, Bt, Ut, !1, null, "32ebb81a", null))
          , $t = Ht.exports
          , Xt = function() {
            var t = this
              , e = t.$createElement
              , s = t._self._c || e;
            return s("body", {
                staticClass: "bg"
            }, [s("div", {
                directives: [{
                    name: "show",
                    rawName: "v-show",
                    value: !t.showInv,
                    expression: "!showInv"
                }],
                attrs: {
                    id: "content"
                }
            }, [s("div", {
                staticClass: "narrow-left-box"
            }, [s("div", {
                staticClass: "verification-box"
            }, [s("form", {
                staticClass: "clearfix",
                attrs: {
                    id: "validateForm",
                    method: "post",
                    action: "PCValidateServlet"
                }
            }, [s("div", {
                staticClass: "row mt50"
            }, [s("div", {
                staticClass: "col1"
            }, [t._v("行程单号")]), s("div", {
                staticClass: "col2 eticket-box"
            }, [s("input", {
                directives: [{
                    name: "model",
                    rawName: "v-model",
                    value: t.validateForm.invoiceNo,
                    expression: "validateForm.invoiceNo"
                }],
                attrs: {
                    type: "text",
                    maxlength: "12"
                },
                domProps: {
                    value: t.validateForm.invoiceNo
                },
                on: {
                    input: function(e) {
                        e.target.composing || t.$set(t.validateForm, "invoiceNo", e.target.value)
                    }
                }
            }), t.validateInfo.isIrnoPass ? t._e() : [s("div", {
                directives: [{
                    name: "show",
                    rawName: "v-show",
                    value: t.showIrnoTip,
                    expression: "showIrnoTip"
                }],
                staticClass: "eticket-hover-box "
            }, [s("span", {
                staticClass: "verification-arrow"
            }), s("p", [t._v("输入11位航空运输电子客票行程单印刷序号。")])]), s("i", {
                directives: [{
                    name: "show",
                    rawName: "v-show",
                    value: t.showIrnoTip,
                    expression: "showIrnoTip"
                }],
                staticClass: "icon-close clear-text-ico",
                on: {
                    click: function(e) {
                        return t.close("irno")
                    }
                }
            })]], 2)]), s("div", {
                staticClass: "row mt20"
            }, [s("div", {
                staticClass: "col1"
            }, [t._v("旅客姓名")]), s("div", {
                staticClass: "col2 passenger-box"
            }, [s("input", {
                directives: [{
                    name: "model",
                    rawName: "v-model",
                    value: t.validateForm.passengerName,
                    expression: "validateForm.passengerName"
                }],
                attrs: {
                    type: "text",
                    maxlength: "30"
                },
                domProps: {
                    value: t.validateForm.passengerName
                },
                on: {
                    input: function(e) {
                        e.target.composing || t.$set(t.validateForm, "passengerName", e.target.value)
                    }
                }
            }), t.validateInfo.isPsgPass ? t._e() : [s("div", {
                directives: [{
                    name: "show",
                    rawName: "v-show",
                    value: t.showPsgTip,
                    expression: "showPsgTip"
                }],
                staticClass: "passenger-hover-box "
            }, [s("span", {
                staticClass: "verification-arrow"
            }), s("p", [t._v("订票时输入的旅客姓名，英文名请注意格式。")])]), s("i", {
                directives: [{
                    name: "show",
                    rawName: "v-show",
                    value: t.showPsgTip,
                    expression: "showPsgTip"
                }],
                staticClass: "icon-close clear-text-ico ",
                on: {
                    click: function(e) {
                        return t.close("psg")
                    }
                }
            })]], 2)]), s("div", {
                staticClass: "row mt20"
            }, [s("div", {
                staticClass: "col1"
            }, [t._v("电子客票号")]), s("div", {
                staticClass: "col2"
            }, [s("input", {
                directives: [{
                    name: "model",
                    rawName: "v-model",
                    value: t.validateForm.eticketNo,
                    expression: "validateForm.eticketNo"
                }],
                attrs: {
                    type: "text",
                    maxlength: "14"
                },
                domProps: {
                    value: t.validateForm.eticketNo
                },
                on: {
                    input: function(e) {
                        e.target.composing || t.$set(t.validateForm, "eticketNo", e.target.value)
                    }
                }
            })])]), s("div", {
                staticClass: "row mt20"
            }, [s("div", {
                staticClass: "col1"
            }, [t._v("合计总价")]), s("div", {
                staticClass: "col2 price-box"
            }, [s("input", {
                directives: [{
                    name: "model",
                    rawName: "v-model",
                    value: t.validateForm.price,
                    expression: "validateForm.price"
                }],
                attrs: {
                    type: "text",
                    maxlength: "30"
                },
                domProps: {
                    value: t.validateForm.price
                },
                on: {
                    input: function(e) {
                        e.target.composing || t.$set(t.validateForm, "price", e.target.value)
                    }
                }
            }), t.validateInfo.isPricePass ? t._e() : [s("div", {
                directives: [{
                    name: "show",
                    rawName: "v-show",
                    value: t.showPriceTip,
                    expression: "showPriceTip"
                }],
                staticClass: "price-hover-box "
            }, [s("span", {
                staticClass: "verification-arrow"
            }), s("p", [t._v("合计价格不能为零且小数点后仅为两位。")])]), s("i", {
                directives: [{
                    name: "show",
                    rawName: "v-show",
                    value: t.showPriceTip,
                    expression: "showPriceTip"
                }],
                staticClass: "icon-close clear-text-ico ",
                on: {
                    click: function(e) {
                        return t.close("price")
                    }
                }
            })]], 2)]), s("div", {
                staticClass: "row mt20"
            }, [s("div", {
                staticClass: "col1"
            }, [t._v("输入验证码")]), s("div", {
                staticClass: "col2 veri-box"
            }, [s("input", {
                directives: [{
                    name: "model",
                    rawName: "v-model",
                    value: t.validateForm.verificationCode,
                    expression: "validateForm.verificationCode"
                }],
                staticClass: "veri-code-input",
                attrs: {
                    type: "text",
                    maxlength: "6"
                },
                domProps: {
                    value: t.validateForm.verificationCode
                },
                on: {
                    input: function(e) {
                        e.target.composing || t.$set(t.validateForm, "verificationCode", e.target.value)
                    }
                }
            }), s("captcha", {
                ref: "captcha",
                on: {
                    refreshCaptchaToken: t.refreshCaptchaToken
                }
            })], 1)]), s("div", {
                staticClass: "row error-txt-row "
            }, [s("div", {
                staticClass: "col1"
            }), s("div", {
                staticClass: "col2"
            }, [s("span", {
                directives: [{
                    name: "show",
                    rawName: "v-show",
                    value: !t.validateInfo.isCodePass || !t.validateInfo.isEtnoPass,
                    expression: "!validateInfo.isCodePass || !validateInfo.isEtnoPass"
                }],
                staticClass: "error-txt "
            }, [t._v("电子票号或验证码不正确")])])]), s("div", {
                staticClass: "row btn-row "
            }, [s("div", {
                staticClass: "col-btn"
            }, [s("input", {
                staticClass: "verification-btn",
                attrs: {
                    type: "button",
                    value: "验真"
                },
                on: {
                    click: function(e) {
                        return t.validate()
                    }
                }
            })])]), t._m(0), t._m(1)])])]), s("div", {
                staticClass: "result-box w-665"
            }, [s("div", {
                staticClass: "seal-pic"
            }), s("div", {
                staticClass: "clearfix rs-box"
            }, [s("div", {
                staticClass: "u-result"
            }, [t.loading ? s("div", {
                staticClass: "u-loading"
            }, [s("img", {
                attrs: {
                    src: i("7976")
                }
            })]) : t._e(), t.isActive ? s("span", [t._v(t._s(t.msg))]) : t._e()])])]), t._m(2)]), s("div", {
                directives: [{
                    name: "show",
                    rawName: "v-show",
                    value: t.showInv,
                    expression: "showInv"
                }],
                staticClass: "clearfix v-info-box  ",
                attrs: {
                    id: "popup_detail"
                }
            }, [s("div", {
                staticClass: "view-info-box"
            }, [s("ul", {
                staticClass: "one-ul"
            }, [s("li", [s("div", {
                staticClass: "chayan-order"
            }, [s("span", {
                staticClass: "chayan-order-num"
            }, [t._v(" " + t._s(t.itinerary.gP))]), s("span", [t._v("印刷序号：" + t._s("1" == t.itinerary.status ? t.itinerary.serialNumber + " " + t.itinerary.mod : "2" == t.itinerary.status ? "作废" : "未使用"))])]), s("span", {
                staticClass: "ml726"
            }, [t._v("SERIAL NUMBER：")])])]), s("ul", {
                staticClass: "two-ul"
            }, [s("li", [s("span", {
                staticClass: "ml27",
                staticStyle: {
                    width: "172px"
                }
            }, [t._v(" " + t._s(t.itinerary.passenger.name) + " ")]), s("span", {
                staticClass: "identity-card"
            }, [t._v(" " + t._s(t.itinerary.passenger.id) + " ")]), s("span", {
                staticClass: "visa"
            }, [t._v(" " + t._s(t.itinerary.passenger.endorsements) + " ")])])]), s("div", {
                staticClass: "pnr-no",
                staticStyle: {
                    height: "32px"
                }
            }), s("table", {
                staticClass: "journey-detail"
            }, [s("tbody", t._l(t.itinerary.journeys, (function(e) {
                return s("tr", {
                    key: e.seq,
                    attrs: {
                        align: "center",
                        width: "996"
                    }
                }, [s("td", {
                    attrs: {
                        width: "50",
                        align: "right",
                        valign: "top"
                    }
                }, [s("p", {
                    staticStyle: {
                        width: "50px",
                        "line-height": "25px"
                    }
                }, [t._v(t._s(e.airport.terminal))])]), s("td", {
                    attrs: {
                        width: "80",
                        valign: "top"
                    }
                }, [s("p", {
                    staticStyle: {
                        width: "80px",
                        "line-height": "25px"
                    }
                }, [t._v(t._s(e.airport.city))])]), s("td", {
                    attrs: {
                        width: "45",
                        valign: "top"
                    }
                }, [s("p", {
                    staticStyle: {
                        width: "45px",
                        "line-height": "25px"
                    }
                }, [t._v(t._s(e.airport.code))])]), s("td", {
                    attrs: {
                        width: "40",
                        align: "left",
                        valign: "top"
                    }
                }, [s("p", {
                    staticStyle: {
                        width: "40px",
                        "line-height": "25px"
                    }
                }, [t._v(t._s(e.carrier))])]), s("td", {
                    attrs: {
                        width: "60",
                        valign: "top"
                    }
                }, [s("p", {
                    staticStyle: {
                        width: "60px",
                        "line-height": "25px"
                    }
                }, [t._v(t._s(e.flight))])]), s("td", {
                    attrs: {
                        width: "40",
                        valign: "top"
                    }
                }, [s("p", {
                    staticStyle: {
                        width: "40px",
                        "line-height": "25px"
                    }
                }, [t._v(t._s(e.flightClass))])]), s("td", {
                    attrs: {
                        width: "100",
                        valign: "top",
                        align: "center"
                    }
                }, [s("p", {
                    staticStyle: {
                        width: "100px",
                        "line-height": "25px"
                    }
                }, [t._v(t._s(e.date))])]), s("td", {
                    attrs: {
                        width: "85",
                        valign: "top",
                        align: "left"
                    }
                }, [s("p", {
                    staticStyle: {
                        width: "85px",
                        "line-height": "25px"
                    }
                }, [t._v(t._s(e.time))])]), s("td", {
                    attrs: {
                        width: "150",
                        valign: "top"
                    }
                }, [s("p", {
                    staticStyle: {
                        width: "150px",
                        "line-height": "25px"
                    }
                }, [t._v(t._s(e.fareBasis))])]), s("td", {
                    attrs: {
                        width: "100",
                        valign: "top"
                    }
                }, [s("p", {
                    staticStyle: {
                        width: "100px",
                        "line-height": "25px"
                    }
                }, [t._v(t._s(e.notValidBefore))])]), s("td", {
                    attrs: {
                        width: "100",
                        valign: "top"
                    }
                }, [s("p", {
                    staticStyle: {
                        width: "100px",
                        "line-height": "25px"
                    }
                }, [t._v(t._s(e.notValidAfter))])]), s("td", {
                    attrs: {
                        width: "80",
                        valign: "top"
                    }
                }, [s("p", {
                    staticStyle: {
                        width: "80px",
                        "line-height": "25px"
                    }
                }, [t._v(t._s(e.allow))])])])
            }
            )), 0)]), s("ul", {
                staticClass: "six-ul"
            }, [s("li", [s("span", {
                staticClass: "fare"
            }, [t._v(" " + t._s(t.itinerary.pricing.fare) + " ")]), s("span", {
                staticClass: "caac-development-fund"
            }, [t._v(" " + t._s(t.itinerary.pricing.caacDevelopmentFund) + " ")]), s("span", {
                staticClass: "fuel-surcharge"
            }, [t._v(" " + t._s(t.itinerary.pricing.fuelSurcharger) + " ")]), s("span", {
                staticClass: "other-taxes"
            }, [t._v(t._s(t.itinerary.pricing.otherTaxes))]), s("span", {
                staticClass: "cny-total"
            }, [t._v(t._s(t.itinerary.pricing.total))])])]), s("ul", {
                staticClass: "seven-ul"
            }, [s("li", [s("span", {
                staticClass: "e-ticket-no"
            }, [t._v(" " + t._s(t.itinerary.eTicketNO) + " "), s("br"), s("span", {
                staticClass: "u-remark"
            }, [t._v(" " + t._s(t.itinerary.rawRemark) + " ")])]), s("span", {
                staticClass: "ck-info"
            }, [t._v(" " + t._s(t.itinerary.check) + " ")]), s("span", {
                staticClass: "information"
            }, [t._v(" " + t._s(t.itinerary.information) + " ")]), s("span", {
                staticClass: "insurance"
            }, [t._v(" " + t._s(t.itinerary.insurance) + " ")])])]), s("ul", {
                staticClass: "eight-ul"
            }, [s("li", [s("span", {
                staticClass: "agent-code"
            }, [s("p", [t._v(t._s(t.itinerary.office))]), s("p", [t._v(t._s(t.itinerary.iata))])]), s("span", {
                staticClass: "issue-by"
            }, [t._v(" " + t._s(t.itinerary.issueBy) + " ")]), s("span", {
                staticClass: "date-off-issue"
            }, [t._v(" " + t._s(t.itinerary.dateOfIssue) + " ")])])])]), s("div", {
                staticClass: "clearfix close-view-box"
            }, [s("a", {
                staticClass: "close-view",
                staticStyle: {
                    cursor: "pointer"
                },
                on: {
                    click: function(e) {
                        t.showInv = !1
                    }
                }
            }, [t._v("关闭")])])]), s("div", {
                staticClass: "gray-bk hide",
                staticStyle: {
                    height: "3266px"
                }
            })])
        }
          , Yt = [function() {
            var t = this
              , e = t.$createElement
              , i = t._self._c || e;
            return i("div", {
                staticClass: "row mt10"
            }, [i("div", {
                staticClass: "col4"
            }, [i("span", [t._v("三方验真平台：")]), i("a", {
                staticClass: "ref",
                attrs: {
                    target: "_blank",
                    href: "https://extra.csair.com/content/checkTicket/index.html?lang=zh#/search"
                }
            }, [t._v("南方航空")]), i("a", {
                staticClass: "ref",
                attrs: {
                    target: "_blank",
                    href: "http://flights.ch.com/show-check-ticket"
                }
            }, [t._v("春秋航空")]), i("a", {
                staticClass: "ref",
                attrs: {
                    target: "_blank",
                    href: "http://www.9air.com/ticketconfirm.html"
                }
            }, [t._v("九元航空")])])])
        }
        , function() {
            var t = this
              , e = t.$createElement
              , i = t._self._c || e;
            return i("div", {
                staticClass: "row"
            }, [i("div", {
                staticClass: "col1"
            }, [t._v("验真服务电话：")]), i("div", {
                staticClass: "col2 line-height30"
            }, [i("span", {
                staticClass: "hotline new-hotline"
            }, [t._v("400-815-8888")])])])
        }
        , function() {
            var t = this
              , e = t.$createElement
              , i = t._self._c || e;
            return i("div", {
                staticClass: "clearfix tip-box"
            }, [i("div", {
                staticClass: "tip-insurance"
            }), i("div", {
                staticClass: "tip-lititle"
            }, [i("span", [t._v("由于国际业务较为复杂，有些远程系统提供的信息可能不正确或不完整，")]), t._v(" "), i("span", [t._v("对于个别国际票，请从出票机构或承运人处获取准确信息。")])])])
        }
        ]
          , zt = {
            name: "pcValidate",
            components: {
                captcha: pt
            },
            data: function() {
                return {
                    showIrnoTip: !0,
                    showPsgTip: !0,
                    showPriceTip: !0,
                    showInv: !1,
                    isActive: !1,
                    msg: "",
                    timer: null,
                    loading: !1
                }
            },
            computed: Object(h["a"])(Object(h["a"])({}, Object(Lt["c"])("pcValidatorByCaacCtrl", ["GET_RENDER_DATA", "GET_VALIDATEFORM", "GET_TICKETINFO", "GET_VALIDATEINFO"])), {}, {
                renderData: function() {
                    return this["GET_RENDER_DATA"]
                },
                validateForm: function() {
                    return this["GET_VALIDATEFORM"]
                },
                itinerary: function() {
                    return this["GET_TICKETINFO"]
                },
                validateInfo: function() {
                    return this["GET_VALIDATEINFO"]
                }
            }),
            methods: Object(h["a"])(Object(h["a"])({}, Object(Lt["b"])("pcValidatorByCaacCtrl", ["DO_INIT_DATA", "DO_VALIDATE_ITI", "DO_UPDATE_SHOWRESULT", "DO_VALIDATE_IRNO"])), {}, {
                initData: function() {
                    this["DO_INIT_DATA"]().then((function() {}
                    )).catch((function() {}
                    ))
                },
                refreshCaptchaImg: function() {
                    this.$refs.captcha.refresh()
                },
                handler: function() {
                    this.isActive = !1
                },
                validate: function() {
                    var t = this;
                    t.showIrnoTip = !0,
                    t.showPsgTip = !0,
                    t.showPriceTip = !0,
                    this["DO_VALIDATE_ITI"](this.validateForm).then((function(e) {
                        var i = e.data;
                        i.success ? (t.isActive = !1,
                        t.showInv = !0) : (t.msg = i.msg,
                        t.timer ? (clearTimeout(t.timer),
                        t.timer = setTimeout(t.handler, 4e3)) : t.timer = setTimeout(t.handler, 4e3),
                        t.isActive = !0,
                        t.showInv = !1),
                        t.refreshCaptchaImg()
                    }
                    )).catch((function(e) {
                        null !== e.msg && void 0 !== e.msg && (t.msg = e.msg,
                        t.timer ? (clearTimeout(t.timer),
                        t.timer = setTimeout(t.handler, 4e3)) : t.timer = setTimeout(t.handler, 4e3),
                        t.isActive = !0,
                        t.showInv = !1),
                        t.refreshCaptchaImg()
                    }
                    ))
                },
                refreshCaptchaToken: function(t) {
                    rt.a.set({
                        "x-captcha-token-key": t
                    })
                },
                close: function(t) {
                    var e = this;
                    "irno" === t ? e.showIrnoTip = !1 : "psg" === t ? e.showPsgTip = !1 : "price" === t && (e.showPriceTip = !1)
                }
            }),
            created: function() {
                this.initData()
            }
        }
          , te = zt
          , ee = (i("a095"),
        i("b81c"),
        i("a0b4"),
        i("ee43"),
        Object(u["a"])(te, Xt, Yt, !1, null, "6578d401", null))
          , ie = ee.exports;
        n["a"].use(p["a"]);
        var se = new p["a"]({
            mode: "history",
            routes: [{
                path: "/",
                name: "index",
                component: Jt
            }, {
                path: "/question",
                name: "question",
                component: $t
            }, {
                path: "/itinerary",
                name: "itinerary",
                component: qt,
                props: function(t) {
                    return {
                        ticketInfo: t.params.ticketInfo
                    }
                }
            }, {
                path: "/pcValidate",
                name: "pcValidate",
                component: ie
            }]
        })
          , ae = (i("498a"),
        i("2ef0"))
          , ne = i.n(ae);
        i("c975");
        function re(t) {
            var e = /\D/;
            return !e.test(t)
        }
        function oe(t) {
            var e = t.length;
            return t = t.toUpperCase(),
            !(11 !== e || !re(t))
        }
        function ce(t) {
            var e = t.length;
            return t = t.toUpperCase(),
            13 == e ? !!re(t) : 14 === e && (3 != t.indexOf("-") ? (console.log("输入的电子票号格式不对，前三位和后十位用“-”分割！"),
            !1) : re(t.substring(0, 3)) ? !!re(t.substring(4, e)) || (console.log("请确认后10位全部为数字！"),
            !1) : (console.log("请确认前3位全部为数字！"),
            !1))
        }
        function le(t) {
            var e = /^(([1-9][0-9]*)|(([0]\.\d{1,2}|[1-9][0-9]*\.\d{1,2})))$/;
            return !e.test(t)
        }
        var ue = {
            state: {
                validateForm: {
                    eticketNo: "",
                    invoiceNo: "",
                    price: "",
                    passengerName: "",
                    verificationCode: ""
                },
                validateInfo: {
                    isIrnoPass: !0,
                    irnomsg: "",
                    isEtnoPass: !0,
                    etnomsg: "",
                    isPsgPass: !0,
                    psgmsg: "",
                    isPricePass: !0,
                    pricemsg: "",
                    isCodePass: !0,
                    codemsg: ""
                },
                showResult: !1,
                ticketInfo: {
                    elEticketSeq: "",
                    serial_number: "",
                    signingInfo: "",
                    pnrNo: "",
                    passenger: {
                        name: "",
                        ID_NO: ""
                    },
                    depAirportTerminal: "",
                    depAirportCode: "",
                    depCityName: "",
                    arrAirports: [],
                    journeys: [],
                    rawRemark: "",
                    validateCode: "",
                    remark: "",
                    totalPremiumStr: "",
                    pricing: {
                        currencyType: "",
                        fare: "",
                        cnTaxType: "",
                        cnTax: "",
                        yqTaxType: "",
                        yqTax: "",
                        otherTaxType: "",
                        otherTax: "",
                        totalCurrType: "",
                        totalAmount: ""
                    },
                    officeCode: "",
                    e_ticket_NO_r1: "",
                    agent_code: "",
                    issue_by: "",
                    date_of_issue: ""
                }
            },
            actions: {
                DO_INIT_DATA: function(t) {
                    var e = t.commit;
                    return new Promise((function() {
                        e("SET_INITDATA")
                    }
                    ))
                },
                DO_VALIDATE_FORM: function(t) {
                    var e = t.commit
                      , i = t.getters;
                    return new Promise((function(t, s) {
                        var a = JSON.parse(JSON.stringify(i["GET_VALIDATEFORM"]))
                          , n = !1
                          , r = {
                            isIrnoPass: !0,
                            irnomsg: "",
                            isEtnoPass: !0,
                            etnomsg: "",
                            isPsgPass: !0,
                            psgmsg: "",
                            isPricePass: !0,
                            pricemsg: "",
                            isCodePass: !0,
                            codemsg: ""
                        }
                          , o = {};
                        for (var c in a)
                            o[c] = a[c].trim();
                        return a = o,
                        ne.a.isEmpty(a.invoiceNo) ? (r.isIrnoPass = !1,
                        r.irnomsg = "不能为空",
                        n = !1) : (a.invoiceNo = a.invoiceNo.replace(/\s*/g, ""),
                        oe(a.invoiceNo) ? (r.isIrnoPass = !0,
                        r.irnomsg = "",
                        n = !0) : (r.isIrnoPass = !1,
                        r.irnomsg = "格式错误",
                        n = !1)),
                        n ? ne.a.isEmpty(a.passengerName) ? (r.isPsgPass = !1,
                        r.psgmsg = "不能为空",
                        n = !1,
                        s(e("SET_VALIDATEINFO", r)),
                        !1) : (ne.a.isEmpty(a.eticketNo) ? (r.isEtnoPass = !1,
                        r.etnomsg = "不能为空",
                        n = !1) : ce(a.eticketNo) ? n = !0 : (r.isEtnoPass = !1,
                        r.etnomsg = "格式错误",
                        n = !1),
                        n ? !ne.a.isEmpty(a.price) && le(a.price) ? (r.isPricePass = !1,
                        r.pricemsg = "格式错误",
                        n = !1,
                        s(e("SET_VALIDATEINFO", r)),
                        !1) : ne.a.isEmpty(a.verificationCode) ? (r.isCodePass = !1,
                        r.codemsg = "不能为空",
                        n = !1,
                        s(e("SET_VALIDATEINFO", r)),
                        !1) : void (n && (t(e("SET_VALIDATEINFO", r)),
                        t(a))) : (s(e("SET_VALIDATEINFO", r)),
                        !1)) : (s(e("SET_VALIDATEINFO", r)),
                        !1)
                    }
                    ))
                },
                DO_VALIDATE_ITI: function(t, e) {
                    var i = t.dispatch
                      , s = t.commit;
                    return new Promise((function(t) {
                        i("DO_VALIDATE_FORM").then((function() {
                            t(e)
                        }
                        ))
                    }
                    )).then((function(t) {
                        return new Promise((function(e, i) {
                            console.log(t);
                            var s = t.invoiceNo
                              , a = s.substr(0, 10)
                              , n = s.substr(10, 11)
                              , r = a % 7;
                            if (r != n) {
                                var o = {
                                    msg: "无法提取指定单号的行程单信息。此行程单或为春秋、金鹿航等未通过航信系统打印，或为假单。可联系相应航空公司进一步确认。",
                                    success: !1
                                };
                                i(o)
                            } else
                                console.log("!"),
                                e(t)
                        }
                        ))
                    }
                    )).then((function(t) {
                        return new Promise((function(e, i) {
                            var a = {};
                            for (var n in console.log("?"),
                            t)
                                a[n] = t[n].trim();
                            ct(a).then((function(t) {
                                e(t);
                                var a = t.data
                                  , n = a.success
                                  , r = a.data;
                                n ? (e(s("SET_SHOWRESULT", !0)),
                                e(s("SET_TICKETINFO", r))) : i()
                            }
                            ))
                        }
                        ))
                    }
                    ))
                },
                DO_UPDATE_SHOWRESULT: function(t, e) {
                    var i = t.commit;
                    return new Promise((function(t) {
                        t(i("SET_SHOWRESULT", e))
                    }
                    ))
                }
            },
            mutations: {
                SET_TICKETINFO: function(t) {
                    var e = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {};
                    t.ticketInfo = e
                },
                SET_INITDATA: function(t) {
                    t.showResult = !1,
                    t.validateForm.eticketNo = "",
                    t.validateForm.invoiceNo = "",
                    t.validateForm.passengerName = "",
                    t.validateForm.price = "",
                    t.validateForm.verificationCode = ""
                },
                SET_SHOWRESULT: function(t) {
                    var e = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {};
                    t.showResult = e
                },
                SET_VALIDATEINFO: function(t) {
                    var e = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {};
                    t.validateInfo.isIrnoPass = e.isIrnoPass,
                    t.validateInfo.irnomsg = e.irnomsg,
                    t.validateInfo.isEtnoPass = e.isEtnoPass,
                    t.validateInfo.etnomsg = e.etnomsg,
                    t.validateInfo.isPricePass = e.isPricePass,
                    t.validateInfo.pricemsg = e.pricemsg,
                    t.validateInfo.isPsgPass = e.isPsgPass,
                    t.validateInfo.psgmsg = e.psgmsg,
                    t.validateInfo.isCodePass = e.isCodePass,
                    t.validateInfo.codemsg = e.codemsg
                }
            },
            getters: {
                GET_RENDER_DATA: function(t) {
                    return t
                },
                GET_VALIDATEFORM: function(t) {
                    return t.validateForm
                },
                GET_TICKETINFO: function(t) {
                    return t.ticketInfo
                },
                GET_VALIDATEINFO: function(t) {
                    return t.validateInfo
                }
            },
            namespaced: !0
        }
          , ve = ue
          , de = {
            state: {
                validateForm: {
                    eticketNo: "",
                    invoiceNo: "",
                    price: "",
                    passengerName: "",
                    verificationCode: ""
                },
                validateInfo: {
                    isIrnoPass: !0,
                    irnomsg: "",
                    isEtnoPass: !0,
                    etnomsg: "",
                    isPsgPass: !0,
                    psgmsg: "",
                    isPricePass: !0,
                    pricemsg: "",
                    isCodePass: !0,
                    codemsg: ""
                },
                showResult: !1,
                ticketInfo: {
                    elEticketSeq: "",
                    serial_number: "",
                    signingInfo: "",
                    pnrNo: "",
                    passenger: {
                        name: "",
                        ID_NO: ""
                    },
                    depAirportTerminal: "",
                    depAirportCode: "",
                    depCityName: "",
                    arrAirports: [],
                    journeys: [],
                    rawRemark: "",
                    validateCode: "",
                    remark: "",
                    totalPremiumStr: "",
                    pricing: {
                        currencyType: "",
                        fare: "",
                        cnTaxType: "",
                        cnTax: "",
                        yqTaxType: "",
                        yqTax: "",
                        otherTaxType: "",
                        otherTax: "",
                        totalCurrType: "",
                        totalAmount: ""
                    },
                    officeCode: "",
                    e_ticket_NO_r1: "",
                    agent_code: "",
                    issue_by: "",
                    date_of_issue: ""
                }
            },
            actions: {
                DO_INIT_DATA: function(t) {
                    var e = t.commit;
                    return new Promise((function() {
                        e("SET_INITDATA")
                    }
                    ))
                },
                DO_VALIDATE_FORM: function(t) {
                    var e = t.commit
                      , i = t.getters;
                    return new Promise((function(t, s) {
                        var a = JSON.parse(JSON.stringify(i["GET_VALIDATEFORM"]))
                          , n = !1
                          , r = {
                            isIrnoPass: !0,
                            irnomsg: "",
                            isEtnoPass: !0,
                            etnomsg: "",
                            isPsgPass: !0,
                            psgmsg: "",
                            isPricePass: !0,
                            pricemsg: "",
                            isCodePass: !0,
                            codemsg: ""
                        }
                          , o = {};
                        for (var c in a)
                            o[c] = a[c].trim();
                        return a = o,
                        ne.a.isEmpty(a.invoiceNo) ? (r.isIrnoPass = !1,
                        r.irnomsg = "不能为空",
                        n = !1) : (a.invoiceNo = a.invoiceNo.replace(/\s*/g, ""),
                        oe(a.invoiceNo) ? (r.isIrnoPass = !0,
                        r.irnomsg = "",
                        n = !0) : (r.isIrnoPass = !1,
                        r.irnomsg = "格式错误",
                        n = !1)),
                        n ? ne.a.isEmpty(a.passengerName) ? (r.isPsgPass = !1,
                        r.psgmsg = "不能为空",
                        n = !1,
                        s(e("SET_VALIDATEINFO", r)),
                        !1) : (ne.a.isEmpty(a.eticketNo) ? (r.isEtnoPass = !1,
                        r.etnomsg = "不能为空",
                        n = !1) : ce(a.eticketNo) ? n = !0 : (r.isEtnoPass = !1,
                        r.etnomsg = "格式错误",
                        n = !1),
                        n ? !ne.a.isEmpty(a.price) && le(a.price) ? (r.isPricePass = !1,
                        r.pricemsg = "格式错误",
                        n = !1,
                        s(e("SET_VALIDATEINFO", r)),
                        !1) : ne.a.isEmpty(a.verificationCode) ? (r.isCodePass = !1,
                        r.codemsg = "不能为空",
                        n = !1,
                        s(e("SET_VALIDATEINFO", r)),
                        !1) : void (n && (t(e("SET_VALIDATEINFO", r)),
                        t(a))) : (s(e("SET_VALIDATEINFO", r)),
                        !1)) : (s(e("SET_VALIDATEINFO", r)),
                        !1)
                    }
                    ))
                },
                DO_VALIDATE_ITI: function(t, e) {
                    var i = t.dispatch
                      , s = t.commit;
                    return new Promise((function(t) {
                        i("DO_VALIDATE_FORM").then((function() {
                            t(e)
                        }
                        ))
                    }
                    )).then((function(t) {
                        return new Promise((function(e, i) {
                            console.log(t);
                            var s = t.invoiceNo
                              , a = s.substr(0, 10)
                              , n = s.substr(10, 11)
                              , r = a % 7;
                            if (r != n) {
                                var o = {
                                    msg: "无法提取指定单号的行程单信息。此行程单或为春秋、金鹿航等未通过航信系统打印，或为假单。可联系相应航空公司进一步确认。",
                                    success: !1
                                };
                                i(o)
                            } else
                                console.log("!"),
                                e(t)
                        }
                        ))
                    }
                    )).then((function(t) {
                        return new Promise((function(e, i) {
                            var a = {};
                            for (var n in console.log("?"),
                            t)
                                a[n] = t[n].trim();
                            lt(a).then((function(t) {
                                e(t);
                                var a = t.data
                                  , n = a.success
                                  , r = a.data;
                                n ? (e(s("SET_SHOWRESULT", !0)),
                                e(s("SET_TICKETINFO", r))) : i()
                            }
                            ))
                        }
                        ))
                    }
                    ))
                },
                DO_UPDATE_SHOWRESULT: function(t, e) {
                    var i = t.commit;
                    return new Promise((function(t) {
                        t(i("SET_SHOWRESULT", e))
                    }
                    ))
                }
            },
            mutations: {
                SET_TICKETINFO: function(t) {
                    var e = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {};
                    t.ticketInfo = e
                },
                SET_INITDATA: function(t) {
                    t.showResult = !1,
                    t.validateForm.eticketNo = "",
                    t.validateForm.invoiceNo = "",
                    t.validateForm.passengerName = "",
                    t.validateForm.price = "",
                    t.validateForm.verificationCode = ""
                },
                SET_SHOWRESULT: function(t) {
                    var e = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {};
                    t.showResult = e
                },
                SET_VALIDATEINFO: function(t) {
                    var e = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {};
                    t.validateInfo.isIrnoPass = e.isIrnoPass,
                    t.validateInfo.irnomsg = e.irnomsg,
                    t.validateInfo.isEtnoPass = e.isEtnoPass,
                    t.validateInfo.etnomsg = e.etnomsg,
                    t.validateInfo.isPricePass = e.isPricePass,
                    t.validateInfo.pricemsg = e.pricemsg,
                    t.validateInfo.isPsgPass = e.isPsgPass,
                    t.validateInfo.psgmsg = e.psgmsg,
                    t.validateInfo.isCodePass = e.isCodePass,
                    t.validateInfo.codemsg = e.codemsg
                }
            },
            getters: {
                GET_RENDER_DATA: function(t) {
                    return t
                },
                GET_VALIDATEFORM: function(t) {
                    return t.validateForm
                },
                GET_TICKETINFO: function(t) {
                    return t.ticketInfo
                },
                GET_VALIDATEINFO: function(t) {
                    return t.validateInfo
                }
            },
            namespaced: !0
        }
          , pe = de;
        n["a"].use(Lt["a"]);
        var me = new Lt["a"].Store({
            modules: {
                validateCtrl: ve,
                pcValidatorByCaacCtrl: pe
            }
        })
          , fe = me;
        n["a"].config.productionTip = !1,
        new n["a"]({
            render: function(t) {
                return t(d)
            },
            router: se,
            store: fe
        }).$mount("#app")
    },
    6: function(t, e) {},
    "694a": function(t, e, i) {},
    "6b55": function(t, e, i) {
        "use strict";
        var s = i("2960")
          , a = i.n(s);
        a.a
    },
    7: function(t, e) {},
    "75d0": function(t, e, i) {
        "use strict";
        var s = i("9b22")
          , a = i.n(s);
        a.a
    },
    7976: function(t, e) {
        t.exports = "data:image/gif;base64,R0lGODlhvgAOAOYAAP///8nJyQEaS5OTk4qOknNycyB05zWU6CqC6DiW5g1RwgQtgQg9ihho3hxu0ESe+GOo5Fqx+HDK+G7D+HDK9TOM7ojN74+vzgszbGrF9DOO6AtIqWe99zSO6FOs9xtZkS+I2tTU1BlqzoXL7kGa9hRIc2ar5KWkpLy7vFel66bD1QUoYRdo3il53MTExI/N+2K67Clxs5GbpDuJtgc7ikaZ6onV+JuirRlgqzCJ7YmKiz6X9mfD9i6G65vX9gg7lhJdyKje90RRYpOSkrbj+MrJyZubm4qOkZWUlAEZRoqPkgEUPMnIyAIeVI2RlWFhYQEaSkN9oZKVl5STk8zLy83NzQEWRFVgbQIbTbKysmbC7wMeSbCytD2T6jOB6juO6n3N+E6s4DON7jeV53Cw53eUv0qP5lWZ7a2trkuZ3h92xRNb0TFlmHDC6z+Z5l+l4mWs7YKjy4nA7QQxhwg5fnu9+Vy26UKf0n7A+mqx8AAAAAAAAAAAAAAAAAAAAAAAACH/C05FVFNDQVBFMi4wAwEAAAAh+QQEAAAAACwAAAAAvgAOAAAH/4AAACFGQ0MDiImKi4yNjo+QkZKTlJWWl5iNSEZoVYIAOk8FOkcEpqeoqaqrrK2ur7CxsrO0tbarSk5SUygAJ08XQT4WxMXGFiYQysvMECYjx8fJzc3P0dHT1MvW18bZ2s7Q3cXf2tzjyODb4ujl1NYjbWFcIQUyREFg+vv7GRkJAAMKDCihoMGDEgYqBEihocOHDhcqhEixocSBFSleFJgR4saAHR9+ZOhQy50oKAqoCGIDTMZ/I3l0hPlRZkiaG23OHJlA50uePivivBiU4lCJPrXM+JBypQ2EBjMcmEq1KlUeUKNa3ToVa1atXK16/SpBatiqY7+aPduVbMG1bP/TZoV7Vi6MGSWa+gAzoa/fCRw6dNBAeHDhwR04/F0cGDHhx4cVL2ZsWLBgDZcJS57sNzDkw5gHb+YM2PBn0xpGc/aMOvRl1ZM9Y4aMGvbdvCpfcIjAu7cHBMCDCw/uobdx3r+HK0dQ/Pjx5MuFN3fuO/rw6dQjQLfOPHt17sCxU99uXTzvFDFwq8Dj4YF79yQMyJ9Pf/6O9/jh198v/37+/PHxV59//70XoID2FYjfgQgaQKCCDCL4YIERCjjhe13EgEFKF+RRgxgVhJhDAyQ2wEKJKDbQQwUgghiiiCmeGGMPYrjIYog1VjDiiTKmSCKNNr5444glsiBjjyri+GLujizu6COKLAB545JNPomkijm62CKMVqK44pZCtvDBCijoEEcNLTigpggKtOnmm26KoOacdLIJ550KyEnnng7YieebevI5p59/thmooH0WCiiigyoaJ6NrOmoooyLgQIcVLmRxAxAbMMAADQuEKuqootLg6amogkrqqguYiuqrn7K6qquwnqqqrKXWmiquo9KqKwO85vqrp8GG6iusdGBghRAhAIDCDRg0gYUA1FZr7bXYZqvtttx26+234IYr7rjkZgtFEktc4cInIbjgAhMBxCvvvPTWa++9+Oar77789uvvvwAHbG8RRVDRLACBAAAh+QQEAAAAACwBAAIAvAAKAAAH/4BPF3JkJhAQJiMWi4yNi4aHkZKIio6NkJOSiZaWmJmHm5yXn5qVoo+kkaGnFp6fq6eukW9pIGgycim6uhS9vr++CcLDxMPAx8XJwsfMysnMyM7E0MDS09TB1svYvdpjalEXeSluwjzcGdrm1Onq59jt2u/s6gkZ6PXz0PHW+sz8ysZomPFBXI0xB3hIWMiwoYQMByJKnChRoUOGEClqTHjRYcaNEy12XPgRZESRI0uaRNlRJUiWF11utDOjxAU4NTpwmMCzp88JHDpo6EBUg9GjQnf+7BnUqFCiT6EqXcq0qFOhQ7NOpQoU69WrSblW9XrUqdGtVINCzYr0rFieTf+9WpUKo+aFFF88RNjLt28EDwgCCx4sWK9fvoAJK0Zg+DDixYobO/4LmbBkx4krB758OLNmzn49V9abIkaJOGdSPFjNuvUDEgZiy54te4fr1rBp6zZg+zbu3bp7+16dG3jt4ayLG+eNnPjy482VG+/dJQaGODjFiKlQQTt37TkasGhAXnx58ix6bOfe/Xv48/DRq2/vvfv29+fHw+/Bnn5//PqVFyB/69n3n4AInsdfewba916A+ZFHIIP9ifFghAqy18IHK8RRQwsOhCiiiCIoYOKJKJ4owogslpjiiwqsyGKLML4o44wk1pjijTg64KKOJvKI449ACjkjkTreKAJCDnRscQMQGzAg5ZRS0rDAlVhmiSUNVHZppZZgLsBll2SGCeaYZFJpppZopsnAl2te2WaacMY5J5l1rtkmHRhsIUQgACH5BAQAAAAALAEAAgC8AAoAAAf/gE8qcmQmEIeIiCYjFo2Oj42GiZMQi5CQkpSKjJeYmomWnY+Zn6GikZ+bp46kmqanhm9pIGgycikpCbq7vBS+v8C/vMO9wcHEyMbKyMTKxszDzsfQu9LA1NXWwrpjamwXeSlu0DzaGdi65c7n6OrS7Nju6+gJ8srw1PbG+OTmvGMacJQAV2PMgYMID/KQwLChQwkZEkpMuPBhw4gTJ1a0eDGjRo4OMXpEuBGkyJEHSnI8OVKlRZYHQODAcAFOjQ4dNGjImZPDhJ9Ag07ggBPnzpw7dXbwKRQo0aRGdR5d2lToU6RTjVKt6hSrV6RbuQ4FK7WoUaZiryY9ChUtV6I8/4/KpJniC4K7eBF4iMC3r98IHvIKzrv3b9/AgwcXNnw4sWLGfhE7xrsYsuTJeiE3xny3MuPLeVvMjHPGi4HTqHc8WM269QMSqGPLNqDaNWvYs2fXtn07t27erXH7Tg2893DixV8fR15c+OwGG1bEMdOigXXrPcRU0F6h+/btOa6LH9+gh3ftYtJXCD+eRQP37st3T89dvRj24lnEfy+/vvr57O1HXnncnefdevxdF99+5m2HnoH4kQdff/VB2J517gHxQxNltLCGAiAqIIIDJJZoogMihKjiiiKeaGKKLLI4oosvxigjjTXaqOKMOKKo4449kgjjjy0GOaSN0W1xwz0GP8yxwAI0MCDllFQyQMOTWGaZZZRVTnmllmBC2WWVX4a55ZhVmqkll2haqeaZbbr55pNsolmmmitsIUQgACH5BAQAAAAALAEAAgC8AAoAAAf/gE8qQT4WhhYmEIqLjBAmI4eRkomNjY+Sk5WWkJiZmouXnZGUn46cooakn6GoiKWKrJIjbWFcN0QUubkJvL2+vbrBwhS/xbzDwsbFyMPKv8zJzsDQutLT1MTWCdhad2yDNmAUGdoJPNjk2ufM6dbr0O3S7+zl88jxzvbD+Mr6wjA4SoCTkOGAwYMID/KQwLChQ4IJIxpc+LBhQYkJKVa0iDHjRocXO078yFHkSJIQTR7Q+DEDCBwYVPgAw6GDhps2b+K0yWGCz59AJ9TMSdSm0Z5Bfw7FqVNDh6cdkCZV+tSp0ao5pU4VmtNqUZ5bqRJ1uvOm1qlDr1bVGTWsz5ov/2O+4ICgrt27dj1E2Mu3bwQPeAPX1euXL2DBeAkXNow48eK+hxsPfsxY8mTKfy1fpny4BUwVdbwYGE269OgdD1KrXv2AhOnXp1mvdg3bNGrZs2vbxp1bN+nbvFv7/h08Ne3hwHkfb7BhxQUzLRpIny6dhfQeFcRUyK69e4Uc1BtYp24d+3bu28WAtz4+fHnt6c+nBx9++ngW2MXozy7/e/X61OXXnX7wqQdgfT3Ax9+C/rnX3nX87VeggdMB8UMTZbSwhgIcduihCA6EKOKIDojg4YkfkjiiiSiiCKKKK7boIowxypgijSGyaCOHL+Ko44490vijAs1ZccMGP8yxwDeSTC5JAwNQRiklAzQ0aWWTT04ZZZVXXpmlllt26SWYU4pp5Zdkcmmmk2SGuSabbVJ55QpWCBEIADs="
    },
    "7b53": function(t, e, i) {},
    8: function(t, e) {},
    "85ec": function(t, e, i) {},
    9: function(t, e) {},
    "95f9": function(t, e, i) {
        "use strict";
        var s = i("9e1c")
          , a = i.n(s);
        a.a
    },
    "9b22": function(t, e, i) {},
    "9e1c": function(t, e, i) {},
    a095: function(t, e, i) {
        "use strict";
        var s = i("7b53")
          , a = i.n(s);
        a.a
    },
    a0b4: function(t, e, i) {
        "use strict";
        var s = i("f169")
          , a = i.n(s);
        a.a
    },
    a17a: function(t, e, i) {},
    b166: function(t, e, i) {
        "use strict";
        var s = i("694a")
          , a = i.n(s);
        a.a
    },
    b81c: function(t, e, i) {
        "use strict";
        var s = i("cc19")
          , a = i.n(s);
        a.a
    },
    cc19: function(t, e, i) {},
    cc60: function(t, e, i) {},
    e173: function(t, e, i) {
        "use strict";
        var s = i("a17a")
          , a = i.n(s);
        a.a
    },
    e6be: function(t, e, i) {},
    ee43: function(t, e, i) {
        "use strict";
        var s = i("0d93")
          , a = i.n(s);
        a.a
    },
    f169: function(t, e, i) {},
    f75b: function(t, e, i) {},
    faeb: function(t, e, i) {
        t.exports = i.p + "img/back-pc.9301592c.png"
    }
});
